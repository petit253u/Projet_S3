/**
* \file general_fuir.h
* \brief Module de structure et constante
* \author 
* \version 0.1
* \date 
*/

#include "../GENERAL/sdl-light.h"
#include <stdbool.h> 

///////////////////////////////////////////////////////

#define NB_BOUTON_MAX_NAVIG 6

#define HAUTEUR_BOUTON_NAVIG 50

#define LARGEUR_BOUTON_NAVIG 150

#define HAUTEUR_BOUTON_NAVIG_ETAGE 50

#define LARGEUR_BOUTON_NAVIG_ETAGE 75

////////////////////

#define LEQUEL_BOUTON_NAVIG_SAUV 0

#define LEQUEL_BOUTON_NAVIG_NIV_1 1

#define LEQUEL_BOUTON_NAVIG_NIV_2 2

#define LEQUEL_BOUTON_NAVIG_NIV_3 3

#define LEQUEL_BOUTON_NAVIG_ACHAT 4

#define LEQUEL_BOUTON_NAVIG_GO 5

////////////////////

#define X_BOUTON_NAVIG_LIGNE_1 30

#define X_BOUTON_NAVIG_LIGNE_1_2 120

#define X_BOUTON_NAVIG_LIGNE_2 810

////////////////////

#define Y_BOUTON_NAVIG_LIGNE_1 80

#define Y_BOUTON_NAVIG_LIGNE_2 140

#define Y_BOUTON_NAVIG_LIGNE_3 200

#define Y_BOUTON_NAVIG_LIGNE_4 260

#define Y_BOUTON_NAVIG_LIGNE_5 320

#define Y_BOUTON_NAVIG_LIGNE_6 380

#define Y_BOUTON_NAVIG_LIGNE_7 440

#define Y_BOUTON_NAVIG_LIGNE_8 500

#define Y_BOUTON_NAVIG_LIGNE_9 560

///////////////////////////////////////////////////////

#define X_VISEUR_NAVIG_NIV_1 470

#define Y_VISEUR_NAVIG_NIV_1 500

#define X_VISEUR_NAVIG_NIV_2 420

#define Y_VISEUR_NAVIG_NIV_2 460

#define X_VISEUR_NAVIG_NIV_3 350

#define Y_VISEUR_NAVIG_NIV_3 440

///////////////////////////////////////////////////////

struct bouton_navig_s{
	SDL_Surface* sprite;
	SDL_Surface* b1;
	SDL_Surface* b2;
	int x;
	int y;
	int largeur;
	int hauteur;
	bool la; //true : bouton la, false : bouton pas la
};
typedef struct bouton_navig_s bouton_navig_t;

struct navig_s{
	bool ouvert; //true : menu ouvert ; false : menu fermé
	SDL_Surface* fond;
	SDL_Surface* jaquette;
	SDL_Surface* inv_fond;
	SDL_Surface* viseur;
	int nb_bouton;
	bouton_navig_t tabbouton[NB_BOUTON_MAX_NAVIG];
	int lequel; //quel bouton est selectionné ?1: niv 1; 2: niv 2; mais pas SAUV, GO et ACHAT (considéré à 0)
	souris_t souris;
};
typedef struct navig_s navig_t;

