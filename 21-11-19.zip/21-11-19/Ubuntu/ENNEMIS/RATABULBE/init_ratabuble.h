/**
* \file init_joueur.h
* \brief Module d'inititialisation
* \author 
* \version 0.1
* \date 
*/

#ifndef INIT_RATABULBE_H
#define INIT_RATABULBE_H

#include "../GENERAL/sdl-light.h"

void init_paterne_cube_ratabulbe_1(paterne_cube_t* p);

void init_paterne_cube_ratabulbe_2(paterne_cube_t* p);

void init_paterne_cube_ratabulbe_3(paterne_cube_t* p);

void init_paterne_cube_ratabulbe_4(paterne_cube_t* p);

void init_paterne_cube_ratabulbe_i(paterne_cube_t* p,int paterne);

void init_paterne_cube_ratabulbe(ennemi_t* e);

void init_data_ennemi_ratabulbe(ennemi_t* e);

#endif
