#ifndef INIT_CLE_H
#define INIT_CLE_H

#include "../../../GENERAL/sdl-light.h"

void init_lire_code_cle(cle_t* c);

void init_data_cle(cle_t* c, int x, int y, int CODE);

#endif
