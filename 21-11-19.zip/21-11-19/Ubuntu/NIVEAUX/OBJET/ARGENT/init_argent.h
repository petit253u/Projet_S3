#ifndef INIT_ARGENT_H
#define INIT_ARGENT_H

#include "../../../GENERAL/sdl-light.h"

void init_data_argent(argent_t* a, int x, int y);

#endif
