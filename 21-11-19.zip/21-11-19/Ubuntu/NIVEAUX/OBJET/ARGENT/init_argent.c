#include "../../../GENERAL/general.h"

void init_data_argent(argent_t* a, int x, int y){

}
