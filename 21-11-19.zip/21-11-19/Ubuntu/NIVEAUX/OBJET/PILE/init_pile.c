#include "../../../GENERAL/general.h"

void init_data_pile(pile_t* p, int x, int y){
	p->x = x;
	p->y = y;
	p->largeur = LARGEUR_PILE;
	p->hauteur = HAUTEUR_PILE;
	p->s1 = ;
	p->s2 = ;
	p->sprite = p->s1;
}
