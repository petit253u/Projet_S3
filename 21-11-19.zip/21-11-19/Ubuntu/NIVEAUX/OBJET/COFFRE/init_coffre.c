#include "../../../GENERAL/general.h"

void init_data_coffre(coffre_t* c, int x, int y){

}
