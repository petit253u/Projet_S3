#include "../../../GENERAL/sdl-light.h"
#include <stdbool.h> 

///////////////////////////////////////////////////////

#define LARGEUR_COFFRE 200
#define HAUTEUR_COFFRE 200

////////////////////////

#define NB_COFFRE_NIV_1_SALLE_1 
#define NB_COFFRE_NIV_1_SALLE_2 
#define NB_COFFRE_NIV_1_SALLE_3 
#define NB_COFFRE_NIV_1_SALLE_4 
#define NB_COFFRE_NIV_1_SALLE_5 
#define NB_COFFRE_NIV_1_SALLE_6
#define NB_COFFRE_NIV_1_SALLE_7
#define NB_COFFRE_NIV_1_SALLE_8

////////////////////////

#define NB_COFFRE_NIV_2_SALLE_1 
#define NB_COFFRE_NIV_2_SALLE_2 
#define NB_COFFRE_NIV_2_SALLE_3 
#define NB_COFFRE_NIV_2_SALLE_4 
#define NB_COFFRE_NIV_2_SALLE_5 
#define NB_COFFRE_NIV_2_SALLE_6
#define NB_COFFRE_NIV_2_SALLE_7
#define NB_COFFRE_NIV_2_SALLE_8

////////////////////////

#define NB_COFFRE_NIV_3_SALLE_1 
#define NB_COFFRE_NIV_3_SALLE_2 
#define NB_COFFRE_NIV_3_SALLE_3 
#define NB_COFFRE_NIV_3_SALLE_4 
#define NB_COFFRE_NIV_3_SALLE_5 
#define NB_COFFRE_NIV_3_SALLE_6
#define NB_COFFRE_NIV_3_SALLE_7
#define NB_COFFRE_NIV_3_SALLE_8

///////////////////////////////////////////////////////

struct coffre_s{

};
typedef struct coffre_s coffre_t;

