#ifndef INIT_COFFRE_H
#define INIT_COFFRE_H

#include "../../../GENERAL/sdl-light.h"

void init_data_coffre(coffre_t* c, int x, int y);

#endif
