/**
* \file general_fuir.h
* \brief Module de structure et constante
* \author 
* \version 0.1
* \date 
*/

#include "../../../GENERAL/sdl-light.h"
#include <stdbool.h> 

///////////////////////////////////////////////////////

#define LARGEUR_LETTRE 200
#define HAUTEUR_LETTRE 200

////////////////////////

#define LETTRE_CONTENU_1
#define LETTRE_CONTENU_2
#define LETTRE_CONTENU_3
#define LETTRE_CONTENU_4
#define LETTRE_CONTENU_5
#define LETTRE_CONTENU_6
#define LETTRE_CONTENU_7
#define LETTRE_CONTENU_8
#define LETTRE_CONTENU_9
#define LETTRE_CONTENU_10
#define LETTRE_CONTENU_11
#define LETTRE_CONTENU_12
#define LETTRE_CONTENU_13
#define LETTRE_CONTENU_14
#define LETTRE_CONTENU_15
#define LETTRE_CONTENU_16
#define LETTRE_CONTENU_17
#define LETTRE_CONTENU_18
#define LETTRE_CONTENU_19
#define LETTRE_CONTENU_20

////////////////////////

#define NB_LETTRE_NIV_1_SALLE_1 
#define NB_LETTRE_NIV_1_SALLE_2 
#define NB_LETTRE_NIV_1_SALLE_3 
#define NB_LETTRE_NIV_1_SALLE_4 
#define NB_LETTRE_NIV_1_SALLE_5 
#define NB_LETTRE_NIV_1_SALLE_6
#define NB_LETTRE_NIV_1_SALLE_7
#define NB_LETTRE_NIV_1_SALLE_8

////////////////////////

#define NB_LETTRE_NIV_2_SALLE_1 
#define NB_LETTRE_NIV_2_SALLE_2 
#define NB_LETTRE_NIV_2_SALLE_3 
#define NB_LETTRE_NIV_2_SALLE_4 
#define NB_LETTRE_NIV_2_SALLE_5 
#define NB_LETTRE_NIV_2_SALLE_6
#define NB_LETTRE_NIV_2_SALLE_7
#define NB_LETTRE_NIV_2_SALLE_8

////////////////////////

#define NB_LETTRE_NIV_3_SALLE_1 
#define NB_LETTRE_NIV_3_SALLE_2 
#define NB_LETTRE_NIV_3_SALLE_3 
#define NB_LETTRE_NIV_3_SALLE_4 
#define NB_LETTRE_NIV_3_SALLE_5 
#define NB_LETTRE_NIV_3_SALLE_6
#define NB_LETTRE_NIV_3_SALLE_7
#define NB_LETTRE_NIV_3_SALLE_8

///////////////////////////////////////////////////////

struct lettre_s{
	SDL_Surface* sprite;
	SDL_Surface* l1; //lettre normal
	SDL_Surface* l2; //lettre cliquable
	int x;
	int y;
	int largeur;
	int hauteur;
};
typedef struct lettre_s lettre_t;

