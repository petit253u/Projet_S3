#ifndef SDL_LIGHT_AUDIO_H
#define SDL_LIGHT_AUDIO_H

#include <SDL_mixer.h>

void init_audio();

#endif
