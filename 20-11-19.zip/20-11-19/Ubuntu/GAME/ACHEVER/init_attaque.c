#include "../../GENERAL/general.h"

void init_viseur_attaque(viseur_t* v){
	v->x = 100;
	v->y = 100;
	v->centre_x = v->x + TAILLE_COTE_VISEUR/2;
	v->centre_y = v->y + TAILLE_COTE_VISEUR/2;
	v->distance = 0;
	v->tour = 1;
	v->bouge = true;
	v->sprite = load_image("RESSOURCES/ATTAQUE/viseur.bmp");
}

void init_borne_attaque(borne_t* b){
	b->x_cache = X_CACHE_BORNE_ATTAQUE;
	b->y_cache = Y_CACHE_BORNE_ATTAQUE;
	b->largeur_cache = LARGEUR_CACHE_BORNE_ATTAQUE;
	b->hauteur_cache = HAUTEUR_CACHE_BORNE_ATTAQUE;
	b->distance = 0;
	b->bouge = true;
	b->tour = 1;
	b->cache_borne = load_image("RESSOURCES/ATTAQUE/cache_borne.bmp");
	b->borne_couleur = load_image("RESSOURCES/ATTAQUE/borne_puissance.bmp");
}

void init_attaque(attaque_t* a){
	a->ouvert = true;
	init_borne_attaque(&a->borne);
	init_viseur_attaque(&a->viseur);
	a->fond = load_image("RESSOURCES/ATTAQUE/fond_attaque.bmp");
	a->arcade = load_image("RESSOURCES/ARCADE/arcade.bmp");
}
