#ifndef NAVIG_H
#define NAVIG_H

#include "../GENERAL/sdl-light.h"


void update_click_souris_navig(souris_t *souris, int x, int y);

void update_pos_souris_navig(souris_t *souris, int x, int y);

////////////////////////

void handle_event_navig(SDL_Event *event, world_t *world);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void init_graphics_bouton_navig(SDL_Surface *ecran, bouton_navig_t* b);

void init_graphics_navig(SDL_Surface *ecran, navig_t *n);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void refresh_graphics_viseur_navig(SDL_Surface *ecran, navig_t *navig);

void refresh_graphics_bouton_navig(SDL_Surface *ecran, bouton_navig_t* b);

void refresh_graphics_navig(SDL_Surface *ecran, navig_t *navig);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void lire_lequel_navig(world_t *world,SDL_Surface *ecran);

void lire_bouton_navig(world_t *world,SDL_Surface *ecran,int i);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void verif_click_navig(bouton_navig_t* b,souris_t* s,world_t *world,SDL_Surface *ecran,int i);

/////////////////////////

void verif_pos_navig(bouton_navig_t* b,souris_t* s);

/////////////////////////

void verif_navig(world_t *world,SDL_Surface *ecran);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

int boucle_navig(world_t *world,SDL_Surface *ecran);
#endif
