/**
* \file init_fuir.h
* \brief Module d'inititialisation
* \author 
* \version 0.1
* \date 
*/

#ifndef INIT_COFFRE_H
#define INIT_COFFRE_H

#include "../../../GENERAL/sdl-light.h"

void init_data_coffre(coffre_t* c, int x, int y);

#endif
