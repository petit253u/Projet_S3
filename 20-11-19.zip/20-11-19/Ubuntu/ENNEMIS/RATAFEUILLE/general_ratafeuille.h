/**
* \file general_joueur.h
* \brief Module de structure et constante
* \author 
* \version 0.1
* \date 
*/

#include "../GENERAL/sdl-light.h"
#include <stdbool.h> 

///////////////////////////////////////////////////////

#define PV_MAX_RATAFEUILLE 100

#define DIF_FUIR_RATAFEUILLE 4

#define X_RATAFEUILLE 400

#define Y_RATAFEUILLE 300

//////////////////////////////////////////////////////
