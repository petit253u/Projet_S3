/**
* \file general.c
* \brief Module de structure et constante
* \author 
* \version 0.1
* \date 
*/

///////////////////////////////////////////////////////

#include "sdl-light.h"
#include <stdbool.h> 

#define NB_EFFECT_MAX 20

#define NB_MUSIC_MAX 10

///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
///////////////////////////////////////////////////////

typedef struct _Mix_Music Mix_Music;

struct audio_s{
	int nbeffect;
	Mix_Chunk* tabeffect[NB_EFFECT_MAX];
	int nbmusic;
	Mix_Music* tabmusic[NB_MUSIC_MAX];
};
typedef struct audio_s audio_t;

