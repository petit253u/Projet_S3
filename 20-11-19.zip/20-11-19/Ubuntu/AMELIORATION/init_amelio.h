/**
* \file init_fuir.h
* \brief Module d'inititialisation
* \author 
* \version 0.1
* \date 
*/

#ifndef INIT_AMELIO_H
#define INIT_AMELIO_H

#include "../GENERAL/sdl-light.h"

void init_souris_amelio(souris_t* s);

////////////////////////////////////////////////////////////////////////////////////////////

void init_bouton_amelio_1(bouton_amelio_t* b);

void init_bouton_amelio_2(bouton_amelio_t* b);

void init_bouton_amelio_3(bouton_amelio_t* b);

void init_bouton_amelio_i(bouton_amelio_t* b,int i);

////////////////////////////////////////////////////////////////////////////////////////////

void init_amelio(amelioration_t* a);

#endif
