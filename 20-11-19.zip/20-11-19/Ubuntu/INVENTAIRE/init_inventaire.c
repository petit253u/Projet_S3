#include "../GENERAL/general.h"

void init_code_inventaire_zero(int inv){
	inv = 0;
}

////////////////

void init_code_inventaire_item(int inv){
	temp = (rand() % NB_ITEM_DIF - 1) + CODE_FIOLE_INV;
	switch(temp){
		case CODE_FIOLE_INV:
			inv = CODE_FIOLE_INV;
			break;
		case CODE_SNACK_INV:
			inv = CODE_SNACK_INV;
			break;
		case CODE_BONBON_INV:
			inv = CODE_BONBON_INV;
			break;
		case CODE_PILE_INV:
			inv = CODE_PILE_INV;
			break;
		case CODE_FROMAGE_INV:
			inv = CODE_FROMAGE_INV;
			break;
	}
}

///////////////////////////////////////////////////////

void init_cle_inventaire_zero(int inv){
	inv = 0;
}

/////////////////////

void reinit_cle_inventaire_zero(inventaire_t* i){
	i->nbcle = 0;
	for(int i=0; i<NB_CLE_MAX; i++){
		init_cle_inventaire_zero(&i->tabcode[i]);
	}
}

///////////////////////////////////////////////////////

void init_inventaire(inventaire_t* i){
	i->nbcode = 20;
	for(int i=0; i<NB_CODE_MAX; i++){
		init_code_inventaire_zero(&i->tabcode[i]);
	}
	for(int i=0; i<i->nbcode; i++){
		init_code_inventaire_item(&i->tabcode[i]);
	}
	i->nbcle = 0;
	for(int i=0; i<NB_CLE_MAX; i++){
		init_cle_inventaire_zero(&i->tabcode[i]);
	}
}

