#ifndef SDL_LIGHT_AUDIO_H
#define SDL_LIGHT_AUDIO_H

#include <SDL_mixer.h>
#include <SDL_sound.h>

void init_audio();

#endif
