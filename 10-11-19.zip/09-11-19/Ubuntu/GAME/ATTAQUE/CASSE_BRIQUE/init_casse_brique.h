/**
* \file init_snake.h
* \brief Module d'inititialisation
* \author 
* \version 0.1
* \date 
*/

#ifndef INIT_CASSE_BRIQUE_H
#define INIT_CASSE_BRIQUE_H

#include "../../../GENERAL/sdl-light.h"



#endif
