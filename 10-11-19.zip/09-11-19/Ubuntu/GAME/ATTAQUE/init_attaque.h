/**
* \file init_snake.h
* \brief Module d'inititialisation
* \author 
* \version 0.1
* \date 
*/

#ifndef INIT_ATTAQUE_H
#define INIT_ATTAQUE_H

#include "../../GENERAL/sdl-light.h"

void init_viseur_attaque(viseur_t* v);

void init_borne_attaque(borne_t* b);

void init_attaque(attaque_t* a);

#endif
