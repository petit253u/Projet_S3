#include "../../GENERAL/general.h"

void refresh_g_borne_viseur(borne_t* b, SDL_Surface *ecran){
	printf("2\n");
	apply_surface(b->borne_couleur,ecran,X_CACHE_BORNE_ATTAQUE,Y_CACHE_BORNE_ATTAQUE);
	apply_surface(b->cache_borne,ecran,b->x_cache,b->y_cache);
}

void refresh_g_viseur_viseur(viseur_t* v,SDL_Surface *ecran){
	printf("4\n");
	apply_surface(v->sprite,ecran,v->x,v->y);
}

void refresh_graphics_viseur_attaque(attaque_t* a, SDL_Surface *ecran){
	printf("1\n");
	refresh_g_borne_viseur(&a->borne,ecran);
	printf("3\n");
	apply_surface(a->fond,ecran,75,75); 
	refresh_g_viseur_viseur(&a->viseur,ecran);
	printf("5\n");
	apply_surface(a->arcade,ecran,25,25);
	printf("6\n");
	refresh_surface(ecran);
}

////////////////////

void refresh_g_borne_borne(borne_t* b, SDL_Surface *ecran){
	apply_surface(b->borne_couleur,ecran,X_CACHE_BORNE_ATTAQUE,Y_CACHE_BORNE_ATTAQUE);
	apply_surface(b->cache_borne,ecran,b->x_cache,b->y_cache);
}

void refresh_g_viseur_borne(viseur_t* v,SDL_Surface *ecran){
	apply_surface(v->sprite,ecran,v->x,v->y);
}

void refresh_graphics_borne_attaque(attaque_t* a, SDL_Surface *ecran){
	refresh_g_borne_borne(&a->borne,ecran);
	apply_surface(a->fond,ecran,75,75); 
	refresh_g_viseur_borne(&a->viseur,ecran);
	apply_surface(a->arcade,ecran,25,25);
	refresh_surface(ecran);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////

void verif_tour_viseur(viseur_t* v){
	if(v->centre_x + MOVING_VISEUR_ATTAQUE >= DISTANCE_VISEUR_BORD_DROIT ){
		v->tour = 2;
	}
	if(v->centre_x - MOVING_VISEUR_ATTAQUE <= DISTANCE_VISEUR_BORD_GAUCHE ){
		v->tour = 1;
	}
}

void verif_bouge_viseur(world_t * world){
	if(world->combat.attaque.viseur.bouge == false){
		return;
	}
}

void verif_viseur_attaque(world_t * world){
	verif_tour_viseur(&world->combat.attaque.viseur);
	verif_bouge_viseur(world);
}

////////////////////

void verif_tour_borne(borne_t* b){
	if(b->y_cache + MOVING_BORNE_ATTAQUE >= DISTANCE_BORNE_BORD_HAUT ){
		b->tour = 2;
	}
	if(b->y_cache - MOVING_BORNE_ATTAQUE - HAUTEUR_CACHE_BORNE_ATTAQUE <= DISTANCE_BORNE_BORD_HAUT ){
		b->tour = 1;
	}
}

void verif_bouge_borne(world_t * world){
	if(world->combat.attaque.borne.bouge == false){
		return;
	}
}

void verif_borne_attaque(world_t * world){
	verif_tour_borne(&world->combat.attaque.borne);
	verif_bouge_borne(world);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////

void anim_mouv_viseur(viseur_t* v){
	if(v->tour == 1){
		v->x = v->x + MOVING_VISEUR_ATTAQUE;
	}
	else{
		v->x = v->x - MOVING_VISEUR_ATTAQUE;
	}
}

void anim_mouv_borne(borne_t* b){
	if(b->tour == 1){
		b->y_cache = b->y_cache - MOVING_BORNE_ATTAQUE;
	}
	else{
		b->y_cache = b->y_cache + MOVING_BORNE_ATTAQUE;
	}
}



////////////////////////////////////////////////////////////////////////////////////////////////////////////

void update_data_viseur_attaque(viseur_t* v){
	if(v->bouge == true){
		anim_mouv_viseur(v);
	} 
	v->centre_x = v->x + TAILLE_COTE_VISEUR/2;
	v->centre_y = v->y + TAILLE_COTE_VISEUR/2;
}

void update_data_borne_attaque(borne_t* b){
	if(b->bouge == true){
		anim_mouv_borne(b);
	} 
}	

////////////////////////////////////////////////////////////////////////////////////////////////////////////

void handle_event_viseur_attaque(SDL_Event *event, world_t *world,SDL_Surface *ecran){
	int mouseX, mouseY;
	Uint8 *keystates;
	while( SDL_PollEvent( event ) ) {
		if( event->type == SDL_QUIT ) {
			world->combat.attaque.viseur.bouge = false;
			world->combat.attaque.ouvert = false;
		}
		if( event->type == SDL_MOUSEBUTTONDOWN){
			SDL_GetMouseState(&mouseX, &mouseY);
			world->combat.attaque.viseur.bouge = false;
		}
		keystates = SDL_GetKeyState( NULL );
		if( keystates[ SDLK_p ] ) {
			world->combat.attaque.viseur.bouge = false;
		}
	}
} 

void handle_event_borne_attaque(SDL_Event *event, world_t *world,SDL_Surface *ecran){
	int mouseX, mouseY;
	Uint8 *keystates;
	while( SDL_PollEvent( event ) ) {
		if( event->type == SDL_QUIT ) {
			world->combat.attaque.borne.bouge = false;
			world->combat.attaque.ouvert = false;
		}
		if( event->type == SDL_MOUSEBUTTONDOWN){
			SDL_GetMouseState(&mouseX, &mouseY);
			world->combat.attaque.borne.bouge = false;
		}
		keystates = SDL_GetKeyState( NULL );
		if( keystates[ SDLK_p ] ) {
			world->combat.attaque.borne.bouge = false;
		}
	} 	
} 

////////////////////////////////////////////////////////////////////////////////////////////////////////////

void init_graphics_attaque_viseur(viseur_t* v,SDL_Surface *ecran){
	set_transparence(ecran, v->sprite, 255, 0, 255);
}

void init_graphics_attaque(attaque_t* a, SDL_Surface *ecran){
	set_transparence(ecran, a->fond, 255, 0, 255);
	init_graphics_attaque_viseur(&a->viseur,ecran);
	set_transparence(ecran, a->arcade, 255, 0, 255);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////

void boucle_viseur_attaque(world_t* world, SDL_Surface *ecran){
	SDL_Event* event_viseur;
	while(world->combat.attaque.viseur.bouge == true){
		handle_event_viseur_attaque(event_viseur,world,ecran);
		update_data_viseur_attaque(&world->combat.attaque.viseur);
		verif_viseur_attaque(world);
		refresh_graphics_viseur_attaque(&world->combat.attaque,ecran);
		printf("hfgsvj");
	}
}

void boucle_borne_attaque(world_t* world, SDL_Surface *ecran){
	SDL_Event* event_borne;
	while(world->combat.attaque.borne.bouge == true){
		printf("hfgsvj");
		handle_event_borne_attaque(event_borne,world,ecran);
		update_data_borne_attaque(&world->combat.attaque.borne);
		verif_borne_attaque(world);
		refresh_graphics_borne_attaque(&world->combat.attaque,ecran);
	}
}

void boucle_attaque(world_t* world, SDL_Surface *ecran){
	init_attaque(&world->combat.attaque);
	init_graphics_attaque(&world->combat.attaque,ecran);
	while(world->combat.attaque.ouvert == true){
		boucle_viseur_attaque(world,ecran);
		boucle_borne_attaque(world,ecran);
	}
}


