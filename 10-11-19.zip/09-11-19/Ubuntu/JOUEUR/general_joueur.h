/**
* \file general_joueur.h
* \brief Module de structure et constante
* \author 
* \version 0.1
* \date 
*/

#include "../GENERAL/sdl-light.h"
#include <stdbool.h> 

///////////////////////////////////////////////////////

#define PV_JOUEUR_BASE 100

#define DEFENSE_JOUEUR_BASE 10

#define ATTAQUE_JOUEUR_BASE 0

#define HAUTEUR_JOUEUR 300

#define LARGEUR_JOUEUR 100

#define MOVING_STEP 30

///////////////////////////////////////////////////////

/**
* \brief Représentation du joueur
*/
struct joueur_s{
	int x;
	int y; 
	int largeur;
	int hauteur;
	SDL_Surface* sprite;
	SDL_Surface* s1;
	SDL_Surface* s2;
	char dir;
	int cote;

	int pv;
	int pv_max;
	int def;
	int def_perm;	
	int degat;
	int degat_plus;

	//inventaire_t* inv;

	int argent;
	bool boost_attaque; // true : prochaine attaque sera augmenté ; false : normal
	bool boost_defense; // true : prochaine esquive sera moins douloureuse ; false : normal
};
typedef struct joueur_s joueur_t;
