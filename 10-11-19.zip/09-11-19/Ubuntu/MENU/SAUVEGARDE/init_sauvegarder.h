/**
* \file init_fuir.h
* \brief Module d'inititialisation
* \author 
* \version 0.1
* \date 
*/

#ifndef INIT_MENU_DEMARRER_H
#define INIT_MENU_DEMARRER_H

#include "../../GENERAL/sdl-light.h"

void init_data_debut(menu_entree_t* debut);

#endif
