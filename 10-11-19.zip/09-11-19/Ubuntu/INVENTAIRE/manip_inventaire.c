#include "../GENERAL/general.h"

void recalage_tab_inventaire_item(inventaire_t* inv, int i){
	for(int j =i; j<inv->nbcode-1; j++){
		inv->tabcode[j] = inv->tabcode[j+1];
	}
	inv->tabcode[inv->nbcode-1] = 0;
}

////////////////////

void retirer_element_inventaire_item(inventaire_t* inv, int CODE){
	for(int i =0; i<inv->nbcode; i++){
		if(inv->tabcode[i] == CODE){
			recalage_tab_inventaire_item(inv,i);
			return;
		}
	}
}

///////////////////////////////////////////////////////

bool est_la_element_inventaire_item(inventaire_t* inv, int CODE){
	for(int i =0; i<inv->nbcode; i++){
		if(inv->tabcode[i] == CODE){
			return true;
		}
	}
	return false;
}

///////////////////////////////////////////////////////

void ajout_element_inventaire_item(inventaire_t* inv, int CODE){
	inv->tabcode[inv->nbcode] = CODE;
	inv->nbcode ++;
}

///////////////////////////////////////////////////////
///////////////////////////////////////////////////////

void recalage_tab_inventaire_cle(inventaire_t* inv, int i){
	for(int j =i; j<inv->nbcle-1; j++){
		inv->tabcle[j] = inv->tabcle[j+1];
	}
	inv->tabcle[inv->nbcle-1] = 0;
}

////////////////////

void retirer_element_inventaire_cle(inventaire_t* inv, int CODE){
	for(int i =0; i<inv->nbcle; i++){
		if(inv->tabcle[i] == CODE){
			recalage_tab_inventaire_cle(inv,i);
			return;
		}
	}
}

///////////////////////////////////////////////////////

bool est_la_element_inventaire_cle(inventaire_t* inv, int CODE){
	for(int i =0; i<inv->nbcle; i++){
		if(inv->tabcle[i] == CODE){
			return true;
		}
	}
	return false;
}

///////////////////////////////////////////////////////

void ajout_element_inventaire_cle(inventaire_t* inv, int CODE){
	inv->tabcle[inv->nbcle] = CODE;
	inv->nbcle ++;
}
