# 14-10-19

<b>ERREUR SEGMENTATION REGLEE</b>

## Début gestion collision
    Codage de le détection et du replacement adéquat apres une collision
<ol>
    <li><b>PROBLEME : </b>Replacement incorrect du joueur dans la bonne direction apres la collision avec le sprite bloc</li>
</ol>

## Découpe du Main
    Codage de le détection et du replacement adéquat apres une collision
<ol>
    <li><b>BOUCLE MENU DEMARRER : </b>Boucle s'occupant du menu de départ</li>
    <li><b>BOUCLE JEU : </b>Boucle s'occupant du jeu en général</li>
    <li><b>BOUCLE DE VIDANGE : </b>Boucle s'occupant de clean les infos du jeu</li>
</ol>

## Début Menu-Départ
    Début de codage du menu de départ du jeu 
<ol>
    <li><b>FAIT : </b> Nouvelle structure du menu démarrer : menu_entree_t</li>
    <li><b>FAIT : </b> Squelette du menu démarrer</li>
</ol>

## Sprite
    Dessin de sprites pour le jeu
<ol>
    <li><b>FAIT : </b> Sprite Bouton 1 : Bouton JOUER, la souris n'est pas glissé dessus</li>
    <li><b>FAIT : </b> Sprite Bouton 2 : Bouton JOUER, la souris est dessus</li>
</ol>
