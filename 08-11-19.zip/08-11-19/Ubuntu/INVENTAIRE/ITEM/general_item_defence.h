/**
* \file general_joueur.h
* \brief Module de structure et constante
* \author 
* \version 0.1
* \date 
*/

#include "../GENERAL/sdl-light.h"
#include <stdbool.h> 

///////////////////////////////////////////////////////

#define ITEM_DEFENCE_BOOST 30

///////////////////////////////////////////////////////

