#include "../GENERAL/general.h"


void init_paterne_cube_ratabulbe_1(paterne_cube_t* p){

}

void init_paterne_cube_ratabulbe_2(paterne_cube_t* p){

}

void init_paterne_cube_ratabulbe_3(paterne_cube_t* p){

}

void init_paterne_cube_ratabulbe_4(paterne_cube_t* p){

}

////////////////////////////////////////////////////////////////////////////

void init_paterne_cube_ratabulbe_i(paterne_cube_t* p,int paterne){
	switch(paterne){
		case 1:
			init_paterne_cube_ratabulbe_1(p)
			break;
		case 2:
			init_paterne_cube_ratabulbe_2(p)
			break;
		case 3:
			init_paterne_cube_ratabulbe_3(p)
			break;
		case 4:
			init_paterne_cube_ratabulbe_4(p)
			break;
	}
}

void init_paterne_cube_ratabulbe(ennemi_t* e){
	for(int i = 0; i<NB_PATERNE_CUBE_MAX; i++){
		init_paterne_cube_ratabulbe_i(&e->paterne[i],i+1);
	}
}

////////////////////////////////////////////////////////////////////////////


void init_data_ennemi_ratabulbe(ennemi_t* e){
	e->pv = PV_MAX_RATABULBE;
	e->fuir_dif = DIF_FUIR_RATABUBLE;
	e->sprite = load_image("RESSOURCES/ENNEMI/table.bmp");
	e->x = X_RATABULBE;
	e->y = Y_RATABULBE;
	e->nom = "RATABULBE";
}
