/**
* \file general_joueur.h
* \brief Module de structure et constante
* \author 
* \version 0.1
* \date 
*/

#include "../GENERAL/sdl-light.h"
#include <stdbool.h> 

///////////////////////////////////////////////////////

#define PV_MAX_RATABULBE 100

#define DIF_FUIR_RATABULBE 4

#define X_RATABULBE 400

#define Y_RATABULBE 300

///////////////////////////////////////////////////////


