/**
* \file init_joueur.h
* \brief Module d'inititialisation
* \author 
* \version 0.1
* \date 
*/

#ifndef INIT_ENNEMI_H
#define INIT_ENNEMI_H

#include "../GENERAL/sdl-light.h"

void init_graphics_ennemi(ennemi_t* e,SDL_Surface *ecran);

void init_data_ennemi(ennemi_t* e);

void init_graphics_ennemi_boss(ennemi_boss_t* e,SDL_Surface *ecran);

void init_data_ennemi_boss(ennemi_boss_t* e, int ennemi);

#endif
