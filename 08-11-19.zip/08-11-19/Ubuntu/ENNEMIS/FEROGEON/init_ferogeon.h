/**
* \file init_joueur.h
* \brief Module d'inititialisation
* \author 
* \version 0.1
* \date 
*/

#ifndef INIT_FEROGEON_H
#define INIT_FEROGEON_H

#include "../GENERAL/sdl-light.h"

void init_paterne_cube_foregeon_1(paterne_cube_t* p);

void init_paterne_cube_foregeon_2(paterne_cube_t* p);

void init_paterne_cube_foregeon_3(paterne_cube_t* p);

void init_paterne_cube_foregeon_4(paterne_cube_t* p);

void init_paterne_cube_foregeon_i(paterne_cube_t* p,int paterne);

void init_paterne_cube_foregeon(ennemi_t* e);

void init_data_ennemi_ferogeon(ennemi_t* e);

#endif
