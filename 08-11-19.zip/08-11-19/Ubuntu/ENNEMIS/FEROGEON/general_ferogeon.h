/**
* \file general_joueur.h
* \brief Module de structure et constante
* \author 
* \version 0.1
* \date 
*/

#include "../GENERAL/sdl-light.h"
#include <stdbool.h> 

///////////////////////////////////////////////////////

#define PV_MAX_FEROGEON 100

#define DIF_FUIR_FEROGEON 8

#define X_FOREGEON 400

#define Y_FOREGEON 300

///////////////////////////////////////////////////////

