#ifndef ATTAQUE_H
#define ATTAQUE_H

#include "../../GENERAL/sdl-light.h"

void refresh_g_borne_viseur(borne_t* b, SDL_Surface *ecran);

void refresh_g_viseur_viseur(viseur_t* v,SDL_Surface *ecran);

void refresh_graphics_viseur_attaque(attaque_t* a, SDL_Surface *ecran);

void refresh_g_borne_borne(borne_t* b, SDL_Surface *ecran);

void refresh_g_viseur_borne(viseur_t* v,SDL_Surface *ecran);

void refresh_graphics_borne_attaque(attaque_t* a, SDL_Surface *ecran);

void verif_tour_viseur(viseur_t* v);

void verif_bouge_viseur(world_t * world);

void verif_viseur_attaque(world_t * world);

void verif_tour_borne(borne_t* b);

void verif_bouge_borne(world_t * world);

void verif_borne_attaque(world_t * world);

void anim_mouv_viseur(viseur_t* v);

void anim_mouv_borne(borne_t* b);

void update_data_viseur_attaque(viseur_t* v);

void update_data_borne_attaque(borne_t* b);

void handle_event_viseur_attaque(SDL_Event *event, world_t *world,SDL_Surface *ecran);

void handle_event_borne_attaque(SDL_Event *event, world_t *world,SDL_Surface *ecran);

void init_graphics_attaque_viseur(viseur_t* v,SDL_Surface *ecran);

void init_graphics_attaque(attaque_t* a, SDL_Surface *ecran);

void boucle_viseur_attaque(world_t* world, SDL_Surface *ecran, SDL_Event *event);

void boucle_borne_attaque(world_t* world, SDL_Surface *ecran, SDL_Event *event);

void boucle_attaque(world_t* world, SDL_Surface *ecran);

#endif
