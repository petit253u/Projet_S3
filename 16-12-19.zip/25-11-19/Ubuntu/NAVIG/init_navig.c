#include "../GENERAL/general.h"

void init_data_bouton_navig_sauv(bouton_navig_t* b){
	b->y = Y_BOUTON_NAVIG_LIGNE_7;
	b->x = X_BOUTON_NAVIG_LIGNE_2;
	b->b1 = SDL_LoadBMP("RESSOURCES/NAVIG/bouton_sauvegarde.bmp");
	b->b2 = SDL_LoadBMP("RESSOURCES/NAVIG/bouton_sauvegarde_cliquable.bmp");
	b->la = true;
	b->hauteur = HAUTEUR_BOUTON_NAVIG;
	b->largeur = LARGEUR_BOUTON_NAVIG;
}

void init_data_bouton_navig_niv_1(bouton_navig_t* b){
	b->y = Y_BOUTON_NAVIG_LIGNE_9;
	b->x = X_BOUTON_NAVIG_LIGNE_1;
	b->b1 = SDL_LoadBMP("RESSOURCES/NAVIG/bouton_etage.bmp");
	b->b2 = SDL_LoadBMP("RESSOURCES/NAVIG/bouton_etage_cliquable.bmp");
	b->la = true;
	b->hauteur = HAUTEUR_BOUTON_NAVIG_ETAGE;
	b->largeur = LARGEUR_BOUTON_NAVIG_ETAGE;
}

void init_data_bouton_navig_niv_2(bouton_navig_t* b){
	b->y = Y_BOUTON_NAVIG_LIGNE_9;
	b->x = X_BOUTON_NAVIG_LIGNE_1_2;
	b->b1 = SDL_LoadBMP("RESSOURCES/NAVIG/bouton_etage.bmp");
	b->b2 = SDL_LoadBMP("RESSOURCES/NAVIG/bouton_etage_cliquable.bmp");
	b->la = false;
	b->hauteur = HAUTEUR_BOUTON_NAVIG_ETAGE;
	b->largeur = LARGEUR_BOUTON_NAVIG_ETAGE;
}

void init_data_bouton_navig_niv_3(bouton_navig_t* b){
	b->y = Y_BOUTON_NAVIG_LIGNE_8;
	b->x = X_BOUTON_NAVIG_LIGNE_1;
	b->b1 = SDL_LoadBMP("RESSOURCES/NAVIG/bouton_etage.bmp");
	b->b2 = SDL_LoadBMP("RESSOURCES/NAVIG/bouton_etage_cliquable.bmp");
	b->la = false;
	b->hauteur = HAUTEUR_BOUTON_NAVIG_ETAGE;
	b->largeur = LARGEUR_BOUTON_NAVIG_ETAGE;
}

void init_data_bouton_navig_achat(bouton_navig_t* b){
	b->y = Y_BOUTON_NAVIG_LIGNE_8;
	b->x = X_BOUTON_NAVIG_LIGNE_2;
	b->b1 = SDL_LoadBMP("RESSOURCES/NAVIG/bouton_achat.bmp");
	b->b2 = SDL_LoadBMP("RESSOURCES/NAVIG/bouton_achat_cliquable.bmp");
	b->la = true;
	b->hauteur = HAUTEUR_BOUTON_NAVIG;
	b->largeur = LARGEUR_BOUTON_NAVIG;
}

void init_data_bouton_navig_go(bouton_navig_t* b){
	b->y = Y_BOUTON_NAVIG_LIGNE_9;
	b->x = X_BOUTON_NAVIG_LIGNE_2;
	b->b1 = SDL_LoadBMP("RESSOURCES/NAVIG/bouton_go.bmp");
	b->b2 = SDL_LoadBMP("RESSOURCES/NAVIG/bouton_go_cliquable.bmp");
	b->la = true;
	b->hauteur = HAUTEUR_BOUTON_NAVIG;
	b->largeur = LARGEUR_BOUTON_NAVIG;
}

////////////////////////

void init_data_bouton_navig(bouton_navig_t* b, int i){
	switch(i){
		case LEQUEL_BOUTON_NAVIG_SAUV:
			init_data_bouton_navig_sauv(b);
			break;
		case LEQUEL_BOUTON_NAVIG_NIV_1:
			init_data_bouton_navig_niv_1(b);
			break;
		case LEQUEL_BOUTON_NAVIG_NIV_2:
			init_data_bouton_navig_niv_2(b);
			break;
		case LEQUEL_BOUTON_NAVIG_NIV_3:
			init_data_bouton_navig_niv_3(b);
			break;
		case LEQUEL_BOUTON_NAVIG_ACHAT:
			init_data_bouton_navig_achat(b);
			break;
		case LEQUEL_BOUTON_NAVIG_GO:
			init_data_bouton_navig_go(b);
			break;
	}
	b->sprite = b->b1;
}

void init_data_navig(navig_t* n){
	n->ouvert = true;
	n->fond =  SDL_LoadBMP("RESSOURCES/MENU_DEPART/FONDTITRE.bmp");
	n->jaquette =  SDL_LoadBMP("RESSOURCES/NAVIG/navig_niv.bmp");
	n->inv_fond =  SDL_LoadBMP("RESSOURCES/NAVIG/inventaire_fond_navig.bmp");
	n->viseur = SDL_LoadBMP("RESSOURCES/NAVIG/viseur_navig.bmp");
	n->lequel = 0;
	n->nb_bouton = NB_BOUTON_MAX_NAVIG;
	for(int i = 0; i<n->nb_bouton; i++){
		init_data_bouton_navig(&n->tabbouton[i],i);
	}
	init_data_souris(&n->souris);
}
