/**
* \file init_fuir.h
* \brief Module d'inititialisation
* \author 
* \version 0.1
* \date 
*/

#ifndef INIT_NAVIG_H
#define INIT_NAVIG_H

#include "../GENERAL/sdl-light.h"

void init_data_bouton_navig_sauv(bouton_navig_t* b);

void init_data_bouton_navig_niv_1(bouton_navig_t* b);

void init_data_bouton_navig_niv_2(bouton_navig_t* b);

void init_data_bouton_navig_niv_3(bouton_navig_t* b);

void init_data_bouton_navig_achat(bouton_navig_t* b);

void init_data_bouton_navig_go(bouton_navig_t* b);

////////////////////////

void init_data_bouton_navig(bouton_navig_t* b, int i);

void init_data_navig(navig_t* n);

#endif
