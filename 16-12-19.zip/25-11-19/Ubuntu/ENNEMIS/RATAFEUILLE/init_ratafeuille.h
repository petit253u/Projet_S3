/**
* \file init_joueur.h
* \brief Module d'inititialisation
* \author 
* \version 0.1
* \date 
*/

#ifndef INIT_RATAFEUILLE_H
#define INIT_RATAFEUILLE_H

#include "../GENERAL/sdl-light.h"

void init_paterne_cube_ratafeuille_1(paterne_cube_t* p);

void init_paterne_cube_ratafeuille_2(paterne_cube_t* p);

void init_paterne_cube_ratafeuille_3(paterne_cube_t* p);

void init_paterne_cube_ratafeuille_4(paterne_cube_t* p);

void init_paterne_cube_ratafeuille_i(paterne_cube_t* p,int paterne);

void init_paterne_cube_ratafeuille(ennemi_t* e);

void init_data_ennemi_ratafeuille(ennemi_t* e);

#endif
