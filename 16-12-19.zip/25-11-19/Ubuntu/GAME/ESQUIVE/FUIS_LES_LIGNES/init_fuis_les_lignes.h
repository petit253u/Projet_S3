/**
* \file init_snake.h
* \brief Module d'inititialisation
* \author 
* \version 0.1
* \date 
*/

#ifndef INIT_FUIS_LES_LIGNES_H
#define INIT_FUIS_LES_LIGNES_H

#include "../../../GENERAL/sdl-light.h"



#endif
