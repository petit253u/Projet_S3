#include "../../GENERAL/general.h"

void init_souris_discuter(souris_t* souris){
	souris->x = -100;
	souris->y = -100;
	souris->click_x = -100;
	souris->click_y = -100;
}

/////////////////////////////////////// BOUTON ///////////////////////////////////////////////

void init_bouton_discuter(bouton_discuter_t* b, int code){
	switch(code){
		case CODE_BOUTON_1_DISCUTER:
			b->x = X_LIGNE_1_DISCUTER;
			b->y = Y_LIGNE_1_DISCUTER;
			b->s1 = load_image("RESSOURCES/DISCUTION/bouton_discution.bmp");
			b->s2 = load_image("RESSOURCES/DISCUTION/bouton_discution_cliquable.bmp");
			break;
		case CODE_BOUTON_2_DISCUTER:
			b->x = X_LIGNE_2_DISCUTER;
			b->y = Y_LIGNE_1_DISCUTER;
			b->s1 = load_image("RESSOURCES/DISCUTION/bouton_discution.bmp");
			b->s2 = load_image("RESSOURCES/DISCUTION/bouton_discution_cliquable.bmp");
			break;
		case CODE_BOUTON_3_DISCUTER:
			b->x = X_LIGNE_1_DISCUTER;
			b->y = Y_LIGNE_2_DISCUTER;
			b->s1 = load_image("RESSOURCES/DISCUTION/bouton_discution.bmp");
			b->s2 = load_image("RESSOURCES/DISCUTION/bouton_discution_cliquable.bmp");;
			break;
		case CODE_BOUTON_4_DISCUTER:
			b->x = X_LIGNE_2_DISCUTER;
			b->y = Y_LIGNE_2_DISCUTER;
			b->s1 = load_image("RESSOURCES/DISCUTION/bouton_discution.bmp");
			b->s2 = load_image("RESSOURCES/DISCUTION/bouton_discution_cliquable.bmp");
			break;
	}
	b->code = code;
	b->largeur = LARGEUR_BOUTON_DISCUTER;
	b->hauteur = HAUTEUR_BOUTON_DISCUTER;
	b->sprite = b->s1;
}

/////////////////////////////////////// ALL ///////////////////////////////////////////////

void init_discuter(discuter_t* d){
	d = malloc(sizeof(discuter_t));
	d->arcade = load_image("RESSOURCES/ARCADE/arcade.bmp");
	d->fond = load_image("RESSOURCES/DISCUTION/fond_discution.bmp");
	d->ouvert = true;
	d->nb_bouton = 4;
	for(int i=0; i<d->nb_bouton; i++){
		init_bouton_discuter(d, i+1);
	}
	init_souris_discuter(&d->souris);
	d->code = 0;
}

