/**
* \file init_fuir.h
* \brief Module d'inititialisation
* \author 
* \version 0.1
* \date 
*/

#ifndef INIT_DISCUTER_H
#define INIT_DISCUTER_H

#include "../../GENERAL/sdl-light.h"

void init_souris_discuter(souris_t* souris);

/////////////////////////////////////// BOUTON ///////////////////////////////////////////////

void init_bouton_discuter(bouton_discuter_t* b, int code);

/////////////////////////////////////// ALL ///////////////////////////////////////////////

void init_discuter(discuter_t* d);


#endif
