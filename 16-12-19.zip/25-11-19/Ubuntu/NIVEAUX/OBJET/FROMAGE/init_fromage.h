#ifndef INIT_FROMAGE_H
#define INIT_FROMAGE_H

#include "../../../GENERAL/sdl-light.h"

void init_data_fromage(fromage_t* f, int x, int y);

#endif
