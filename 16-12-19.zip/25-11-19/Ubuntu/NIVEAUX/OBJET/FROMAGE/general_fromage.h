#include "../../../GENERAL/sdl-light.h"
#include <stdbool.h> 

///////////////////////////////////////////////////////

#define LARGEUR_FROMAGE 200
#define HAUTEUR_FROMAGE 200

////////////////////////

#define NB_FROMAGE_NIV_1_SALLE_1 
#define NB_FROMAGE_NIV_1_SALLE_2 
#define NB_FROMAGE_NIV_1_SALLE_3 
#define NB_FROMAGE_NIV_1_SALLE_4 
#define NB_FROMAGE_NIV_1_SALLE_5 
#define NB_FROMAGE_NIV_1_SALLE_6
#define NB_FROMAGE_NIV_1_SALLE_7
#define NB_FROMAGE_NIV_1_SALLE_8

////////////////////////

#define NB_FROMAGE_NIV_2_SALLE_1 
#define NB_FROMAGE_NIV_2_SALLE_2 
#define NB_FROMAGE_NIV_2_SALLE_3 
#define NB_FROMAGE_NIV_2_SALLE_4 
#define NB_FROMAGE_NIV_2_SALLE_5 
#define NB_FROMAGE_NIV_2_SALLE_6
#define NB_FROMAGE_NIV_2_SALLE_7
#define NB_FROMAGE_NIV_2_SALLE_8

////////////////////////

#define NB_FROMAGE_NIV_3_SALLE_1 
#define NB_FROMAGE_NIV_3_SALLE_2 
#define NB_FROMAGE_NIV_3_SALLE_3 
#define NB_FROMAGE_NIV_3_SALLE_4 
#define NB_FROMAGE_NIV_3_SALLE_5 
#define NB_FROMAGE_NIV_3_SALLE_6
#define NB_FROMAGE_NIV_3_SALLE_7
#define NB_FROMAGE_NIV_3_SALLE_8

///////////////////////////////////////////////////////

struct fromage_s{
	int x;
	int y;
	int largeur;
	int hauteur;
	SDL_Surface* sprite;
	SDL_Surface* s1;
	SDL_Surface* s2;
};
typedef struct fromage_s fromage_t;

