#include "../../../GENERAL/general.h"

void init_data_bonbon(bonbon_t* b, int x, int y){
	b->x = x;
	b->y = y;
	b->largeur = LARGEUR_BONBON;
	b->hauteur = HAUTEUR_BONBON;
	b->s1 = ;
	b->s2 = ;
	b->sprite = b->s1;
}
