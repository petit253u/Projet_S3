#ifndef INIT_ARGENT_H
#define INIT_ARGENT_H

#include "../../../GENERAL/sdl-light.h"

void init_data_argent(argent_t* a, int x, int y);

void init_data_argent_val(argent_t* a, int x, int y, int CODE);

void init_data_argent_sans_pos(argent_t* a, int CODE);

#endif
