#include "../../../GENERAL/general.h"

void init_data_argent(argent_t* a, int x, int y){
	a->x = x;
	a->y = y;
	a->largeur = LARGEUR_ARGENT;
	a->hauteur = HAUTEUR_ARGENT;
	int random = (rand() % 50) + 1;
	if(random < 20){
		a->valeur = 1 ;
		a->s1 = ;
		a->s2 = ; 
	}
	else if(random < 35){
		a->valeur = 2 ;
		a->s1 = ;
		a->s2 = ; 
	}
	else if(random < 45){
		a->valeur = 5 ;
		a->s1 = ;
		a->s2 = ; 
	}
	else if(random < 49){
		a->valeur = 10 ;
		a->s1 = ;
		a->s2 = ; 
	}
	else{
		a->valeur = 20 ;
		a->s1 = ;
		a->s2 = ; 
	}
	a->sprite = a->s1;
	a->la = true;
}

void init_data_argent_val(argent_t* a, int x, int y, int CODE){
	a->x = x;
	a->y = y;
	a->largeur = LARGEUR_ARGENT;
	a->hauteur = HAUTEUR_ARGENT;
	switch(CODE){
		case VALEUR_ARGENT_1: 
			a->valeur = 1;
			a->s1 = ;
			a->s2 = ; 
			break;
		case VALEUR_ARGENT_2: 
			a->valeur = 2;
			a->s1 = ;
			a->s2 = ; 
			break;
		case VALEUR_ARGENT_3: 
			a->valeur = 5;
			a->s1 = ;
			a->s2 = ; 
			break;
		case VALEUR_ARGENT_4: 
			a->valeur = 10;
			a->s1 = ;
			a->s2 = ; 
			break;
		case VALEUR_ARGENT_5: 
			a->valeur = 20;
			a->s1 = ;
			a->s2 = ; 
			break;
	}
	a->sprite = a->s1;
	a->la = true;
}

void init_data_argent_sans_pos(argent_t* a, int CODE){
	switch(CODE){
		case VALEUR_ARGENT_1: 
			a->valeur = 1;
			a->s1 = ;
			a->s2 = ; 
			break;
		case VALEUR_ARGENT_2: 
			a->valeur = 2;
			a->s1 = ;
			a->s2 = ; 
			break;
		case VALEUR_ARGENT_3: 
			a->valeur = 5;
			a->s1 = ;
			a->s2 = ; 
			break;
		case VALEUR_ARGENT_4: 
			a->valeur = 10;
			a->s1 = ;
			a->s2 = ; 
			break;
		case VALEUR_ARGENT_5: 
			a->valeur = 20;
			a->s1 = ;
			a->s2 = ; 
			break;
	}
	a->sprite = a->s1;
	a->la = false;
}
