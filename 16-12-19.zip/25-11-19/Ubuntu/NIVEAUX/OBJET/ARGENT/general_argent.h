/**
* \file general_fuir.h
* \brief Module de structure et constante
* \author 
* \version 0.1
* \date 
*/

#include "../../../GENERAL/sdl-light.h"
#include <stdbool.h> 

///////////////////////////////////////////////////////

#define LARGEUR_ARGENT 200
#define HAUTEUR_ARGENT 200

////////////////////////

#define VALEUR_ARGENT_1 
#define VALEUR_ARGENT_2
#define VALEUR_ARGENT_3
#define VALEUR_ARGENT_4
#define VALEUR_ARGENT_5

////////////////////////

#define NB_ARGENT_NIV_1_SALLE_1 
#define NB_ARGENT_NIV_1_SALLE_2 
#define NB_ARGENT_NIV_1_SALLE_3 
#define NB_ARGENT_NIV_1_SALLE_4 
#define NB_ARGENT_NIV_1_SALLE_5 
#define NB_ARGENT_NIV_1_SALLE_6
#define NB_ARGENT_NIV_1_SALLE_7
#define NB_ARGENT_NIV_1_SALLE_8

////////////////////////

#define NB_ARGENT_NIV_2_SALLE_1 
#define NB_ARGENT_NIV_2_SALLE_2 
#define NB_ARGENT_NIV_2_SALLE_3 
#define NB_ARGENT_NIV_2_SALLE_4 
#define NB_ARGENT_NIV_2_SALLE_5 
#define NB_ARGENT_NIV_2_SALLE_6
#define NB_ARGENT_NIV_2_SALLE_7
#define NB_ARGENT_NIV_2_SALLE_8

////////////////////////

#define NB_ARGENT_NIV_3_SALLE_1 
#define NB_ARGENT_NIV_3_SALLE_2 
#define NB_ARGENT_NIV_3_SALLE_3 
#define NB_ARGENT_NIV_3_SALLE_4 
#define NB_ARGENT_NIV_3_SALLE_5 
#define NB_ARGENT_NIV_3_SALLE_6
#define NB_ARGENT_NIV_3_SALLE_7
#define NB_ARGENT_NIV_3_SALLE_8

///////////////////////////////////////////////////////

struct argent_s{
	SDL_Surface* sprite;
	SDL_Surface* l1; //argent normal
	SDL_Surface* l2; //argent cliquable
	int x;
	int y;
	int largeur;
	int hauteur;
	int valeur;
	bool la; 
};
typedef struct argent_s argent_t;

