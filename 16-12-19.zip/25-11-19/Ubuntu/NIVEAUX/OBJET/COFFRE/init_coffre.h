#ifndef INIT_COFFRE_H
#define INIT_COFFRE_H

#include "../../../GENERAL/sdl-light.h"

void init_data_coffre_autre(coffre_t* c, int x, int y, int CODE, int nb_contenu);

void init_data_coffre_lettre(coffre_t* c, int x, int y, int CODE, int nb_contenu, int CODE_LETTRE);

void init_data_coffre_cle(coffre_t* c, int x, int y, int CODE, int nb_contenu, int CODE_CLE);

void init_data_coffre_ouvert(coffre_t* c, int x, int y, int etat);

#endif
