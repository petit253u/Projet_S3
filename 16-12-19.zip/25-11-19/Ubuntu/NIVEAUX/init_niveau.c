#include "../GENERAL/general.h"

void init_niveau_code(niveau_t* n,int CODE){
	switch(CODE){
		case CODE_NIVEAU_1:
			init_niveau_1(n);
			break;
		case CODE_NIVEAU_2:
			init_niveau_2(n);
			break;
		case CODE_NIVEAU_3:
			init_niveau_3(n);
			break;
	}
}
