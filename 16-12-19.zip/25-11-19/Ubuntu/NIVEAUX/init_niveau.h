/**
* \file init_fuir.h
* \brief Module d'inititialisation
* \author 
* \version 0.1
* \date 
*/

#ifndef INIT_NIVEAU_H
#define INIT_NIVEAU_H

#include "../GENERAL/sdl-light.h"

void init_niveau_code(niveau_t* n,int CODE);

#endif
