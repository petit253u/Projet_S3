#include "../GENERAL/general.h"

void lire_objet_affichage_inventaire_terminal(int code){
	switch(code){
		case CODE_FIOLE_INV:
			printf("		FIOLE\n");
			break;
		case CODE_SNACK_INV:
			printf("		SNACK\n");
			break;
		case CODE_BONBON_INV:
			printf("		BONBON\n");
			break;
		case CODE_PILE_INV:
			printf("		PILE\n");
			break;
		case CODE_FROMAGE_INV:
			printf("		FROMAGE\n");
			break;
	}
}

void lire_cle_affichage_inventaire_terminal(int code){
	switch(code){
		case CODE_CLE_BELIER_INV:
			printf("		BELIER\n");
			break;
		case CODE_CLE_TAUREAU_INV:
			printf("		TAUREAU\n");
			break;
		case CODE_CLE_GEMEAU_INV:
			printf("		GEMEAU\n");
			break;
		case CODE_CLE_CANCER_INV:
			printf("		CANCER\n");
			break;
		case CODE_CLE_LION_INV:
			printf("		LION\n");
			break;
		case CODE_CLE_VIERGE_INV:
			printf("		VIERGE\n");
			break;
		case CODE_CLE_BALNCE_INV:
			printf("		BALANCE\n");
			break;
		case CODE_CLE_SCORPION_INV:
			printf("		SCORPION\n");
			break;
		case CODE_CLE_SAGITAIRE_INV:
			printf("		SAGITAIRE\n");
			break;
		case CODE_CLE_CAPRICORNE_INV:
			printf("		CAPRICORNE\n");
			break;
		case CODE_CLE_VERSEAU_INV:
			printf("		VERSEAU\n");
			break;
		case CODE_CLE_POISSON_INV:
			printf("		POISSON\n");
			break;
	}
}

void affichage_inventaire_terminal(inventaire_t* inv){
	printf("INVENTAIRE :\n");
	printf("	CONTENUE :\n");
	for(int i=0; i<inv->nbcode; i++){
		lire_objet_affichage_inventaire_terminal(&inv->tabcode[i]);
	}
	printf("	CLE :\n");
	for(int i=0; i<inv->nbcle; i++){
		lire_cle_affichage_inventaire_terminal(&inv->tabcle[i]);
	}
}

////////////////////

void recalage_tab_inventaire_item(inventaire_t* inv, int i){
	for(int j =i; j<inv->nbcode-1; j++){
		inv->tabcode[j] = inv->tabcode[j+1];
	}
	inv->tabcode[inv->nbcode-1] = 0;
}

////////////////////

void retirer_element_inventaire_item(inventaire_t* inv, int CODE){
	for(int i =0; i<inv->nbcode; i++){
		if(inv->tabcode[i] == CODE){
			recalage_tab_inventaire_item(inv,i);
			return;
		}
	}
}

///////////////////////////////////////////////////////

bool est_la_element_inventaire_item(inventaire_t* inv, int CODE){
	for(int i =0; i<inv->nbcode; i++){
		if(inv->tabcode[i] == CODE){
			return true;
		}
	}
	return false;
}

///////////////////////////////////////////////////////

void ajout_element_inventaire_item(inventaire_t* inv, int CODE){
	inv->tabcode[inv->nbcode] = CODE;
	inv->nbcode ++;
}

///////////////////////////////////////////////////////
///////////////////////////////////////////////////////

void recalage_tab_inventaire_cle(inventaire_t* inv, int i){
	for(int j =i; j<inv->nbcle-1; j++){
		inv->tabcle[j] = inv->tabcle[j+1];
	}
	inv->tabcle[inv->nbcle-1] = 0;
}

////////////////////

void retirer_element_inventaire_cle(inventaire_t* inv, int CODE){
	for(int i =0; i<inv->nbcle; i++){
		if(inv->tabcle[i] == CODE){
			recalage_tab_inventaire_cle(inv,i);
			return;
		}
	}
}

///////////////////////////////////////////////////////

bool est_la_element_inventaire_cle(inventaire_t* inv, int CODE){
	for(int i =0; i<inv->nbcle; i++){
		if(inv->tabcle[i] == CODE){
			return true;
		}
	}
	return false;
}

///////////////////////////////////////////////////////

void ajout_element_inventaire_cle(inventaire_t* inv, int CODE){
	inv->tabcle[inv->nbcle] = CODE;
	inv->nbcle ++;
}
