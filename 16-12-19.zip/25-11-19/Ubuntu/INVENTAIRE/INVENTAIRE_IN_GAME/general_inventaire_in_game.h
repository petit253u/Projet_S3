/**
* \file general_fuir.h
* \brief Module de structure et constante
* \author 
* \version 0.1
* \date 
*/

#include "../../GENERAL/sdl-light.h"
#include <stdbool.h> 

///////////////////////////////////////////////////////

#define NB_BOUTON_MAX_INV_IN_GAME_1 5

#define NB_BOUTON_MAX_INV_IN_GAME_2 2

#define HAUTEUR_BOUTON_1_NAVIG_INV 100

#define LARGEUR_BOUTON_1_NAVIG_INV 350

#define HAUTEUR_BOUTON_2_NAVIG_INV 100

#define LARGEUR_BOUTON_2_NAVIG_INV 350

///////////////////////////////////////////////////////

struct bouton_inv_in_game_s{
	int x;
	int y;
	int largeur;
	int hauteur;
	SDL_Surface* sprite;
	SDL_Surface* s1;
	SDL_Surface* s2;
};
typedef struct bouton_inv_in_game_s bouton_inv_in_game_t;

struct inventaire_in_game_s{
	bool ouvert;
	int x;
	int y;
	SDL_Surface* fond;
	int nbbouton;
	bouton_inv_in_game_t tabbouton[NB_BOUTON_MAX_INV_IN_GAME_1];
	int selection; // Garde en memoire la selection dans l'inventaire : 0 = rien, 1 = ...

	SDL_Surface* fond2;
	int nbbouton2;
	bouton_inv_in_game_t tabbouton2[NB_BOUTON_MAX_INV_IN_GAME_2];
	souris_t s;
};
typedef struct inventaire_in_game_s inventaire_in_game_t;
