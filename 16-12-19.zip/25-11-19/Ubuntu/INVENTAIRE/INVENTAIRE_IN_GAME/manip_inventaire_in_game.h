/**
* \file init_fuir.h
* \brief Module d'inititialisation
* \author 
* \version 0.1
* \date 
*/

#ifndef MANIP_INVENTAIRE_IN_GAME_H
#define MANIP_INVENTAIRE_IN_GAME_H

#include "../../GENERAL/sdl-light.h"



#endif
