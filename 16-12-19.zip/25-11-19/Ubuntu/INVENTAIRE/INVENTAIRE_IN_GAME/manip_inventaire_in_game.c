#include "../../GENERAL/general.h"


void lire_bouton_inventaire_in_game(int i, world_t* world, SDL_Surface *ecran){
	switch(i){
		case CODE_FIOLE_INV:
	
			break;
		case CODE_SNACK_INV:
	
			break;
		case CODE_BONBON_INV:
	
			break;
		case CODE_PILE_INV:
	
			break;
		case CODE_FROMAGE_INV:
	
			break;
	}
}

////////////////////////////////////////

void verif_click_souris_inventaire_in_game((inventaire_in_game_t* inv, int i, world_t* world,SDL_Surface *ecran){
	if((souris->click_x >= inv->tabbouton[i].x)&&(souris->click_x <= inv->tabbouton[i].x + inv->tabbouton[i].largeur)){
		if((souris->click_y >= inv->tabbouton[i].y)&&(souris->click_y <= inv->tabbouton[i].y + inv->tabbouton[i].hauteur)){
			lire_bouton_inventaire_in_game(i,world,ecran);
			init_souris(&world->inv_in_game.s);
			return;
		}
	}
}

void verif_pos_souris_inventaire_in_game(bouton_inv_in_game_t* b){
	if((souris->x >= b->x)&&(souris->x <= b->x + b->largeur)){
		if((souris->y >= b->y)&&(souris->y <= b->y + b->hauteur)){
			b->sprite = b->s2;
			return;
		}
	}
	b->sprite = b->s1;
}

void verif_souris_inventaire_in_game(inventaire_in_game_t* inv,world_t* world,SDL_Surface *ecran){
	for(int i=0; i<inv->nbbouton; i++){
		verif_pos_souris_inventaire_in_game(&inv->tabbouton[i]);
		verif_click_souris_inventaire_in_game(inv,i,world,ecran);
	}
}

/////////////////////////////////////////////////////////////////////////////////////

void update_click_souris_inv_in_game(souris_t* souris, int x, int y){
	souris->click_x = x;
	souris->click_y = y;
}

void update_pos_souris_inv_in_game(souris_t* souris, int x, int y){
	souris->x = x;
	souris->y = y;	
}

/////////////////////////////////////////////////////////////////////////////////////

void init_graphics_bouton_inventaire_in_game(bouton_inv_in_game_t* b, SDL_Surface *ecran){
	set_transparence(ecran, b->s1, 255, 0, 255);
	set_transparence(ecran, b->s2, 255, 0, 255);
}

void init_graphics_inventaire_in_game(SDL_Surface *ecran, inventaire_in_game_t* inv){
	for(int i=0; i<inv->nbbouton; i++){
		init_graphics_bouton_inventaire_in_game(&inv->tabbouton[i],ecran);
	}
	for(int j=0; j<inv->nbbouton2; j++){
		init_graphics_bouton_inventaire_in_game(&inv->tabbouton2[j],ecran);
	}
	set_transparence(ecran, inv->fond, 255, 0, 255);
	set_transparence(ecran, inv->fond2, 255, 0, 255);
}

/////////////////////////////////////////////////////////////////////////////////////

void refresh_graphics_bouton_inventaire_in_game(bouton_inv_in_game_t* b,SDL_Surface *ecran){
	apply_surface(b->sprite,ecran,b->x,b->y);
}

void refresh_graphics_inventaire_in_game(inventaire_in_game_t* inv, SDL_Surface *ecran){
	apply_surface(inv->fond,ecran,25,25); 
	for(int i=0; i<inv->nbbouton; i++){
		refresh_graphics_bouton_inventaire_in_game(&inv->tabbouton[i],ecran);
	}
	refresh_surface(ecran);
}

/////////////////////////////////////////////////////////////////////////////////////

void handle_event_inventaire_in_game(SDL_Event *event, world_t *world){
	int mouseX, mouseY;
	while( SDL_PollEvent( event ) ) {
		//Si l'utilisateur a cliqué sur le X de la fenêtre
		if( event->type == SDL_QUIT ) {
			//On quitte le programme
			world->inv_in_game.ouvert = false;
			world->gameover = 1;
		}
		/* Si l'utilisateur appuie sur
		la touche droite de la souris */
		if( event->type == SDL_MOUSEBUTTONDOWN){
              		SDL_GetMouseState(&mouseX, &mouseY);
			update_click_souris_inv_in_game(&world->inv_in_game.s, mouseX, mouseY);
		}
		if( event->type == SDL_MOUSEMOTION){
			//printf("BOUGE\n");
			SDL_GetMouseState(&mouseX, &mouseY);
			update_pos_souris_inv_in_game(&world->inv_in_game.s, mouseX, mouseY);
		}
	}
} 

/////////////////////////////////////////////////////////////////////////////////////


void boucle_inventaire_in_game(world_t* world,SDL_Surface *ecran){
	SDL_Event event_inv;
	printf("INIT\n");
	init_inventaire_in_game(&world->inv_in_game);
	printf("INIT GRAPHICS\n");
	init_graphics_inventaire_in_game(ecran,&world->inv_in_game);
	printf("CONDITION BOUCLE\n");
	while(world->inv_in_game.ouvert == true){
			handle_event_inventaire_in_game(&event_inv,world);
			verif_souris_inventaire_in_game(&world->inv_in_game,ecran);
			refresh_graphics_inventaire_in_game(&world->inv_in_game,ecran);
	}
}
