#include "../GENERAL/general.h"

void init_code_inventaire_zero(int inv){
	inv = 0;
}

////////////////

void init_code_inventaire_item(int inv){
	int temp = (rand() % NB_ITEM_DIF - 1) + CODE_FIOLE_INV;
	switch(temp){
		case CODE_FIOLE_INV:
			inv = inv+1;
			break;
		case CODE_SNACK_INV:
			inv = inv+1;
			break;
		case CODE_BONBON_INV:
			inv = inv+1;
			break;
		case CODE_PILE_INV:
			inv = inv+1;
			break;
		case CODE_FROMAGE_INV:
			inv = inv+1;
			break;
	}
}

///////////////////////////////////////////////////////

void init_cle_inventaire_zero(int inv){
	inv = 0;
}

///////////////////////////////////////////////////////

void init_inventaire(inventaire_t* inv){
	inv->nbcode = 5;
	for(int i=0; i<inv->nbcode; i++){
		inv->tabcode[i] = 0;
		//init_code_inventaire_zero(&inv->tabcode[i]);
	}
	inv->nbcle = 12;
	for(int i=0; i<inv->nbcle; i++){
		inv->tabcle[i] = 0;
		//init_cle_inventaire_zero(&inv->tabcle[i]);
	}
}

