/**
* \file general_fuir.h
* \brief Module de structure et constante
* \author 
* \version 0.1
* \date 
*/

#include "../GENERAL/sdl-light.h"
#include <stdbool.h> 

///////////////////////////////////////////////////////

#define NB_CODE_MAX 5

/////////////////////

#define NB_ITEM_DIF 5

/////////////////////

#define CODE_FIOLE_INV 0

#define CODE_SNACK_INV 1

#define CODE_BONBON_INV 2

#define CODE_PILE_INV 3

#define CODE_FROMAGE_INV 4

///////////////////////////////////////////////////////

#define NB_CLE_MAX 12

/////////////////////

#define NB_CLE_DIF 12

/////////////////////

#define CODE_CLE_BELIER_INV 0

#define CODE_CLE_TAUREAU_INV 1

#define CODE_CLE_GEMEAU_INV 2

#define CODE_CLE_CANCER_INV 3

#define CODE_CLE_LION_INV 4

#define CODE_CLE_VIERGE_INV 5

#define CODE_CLE_BALNCE_INV 6

#define CODE_CLE_SCORPION_INV 7

#define CODE_CLE_SAGITAIRE_INV 8

#define CODE_CLE_CAPRICORNE_INV 9

#define CODE_CLE_VERSEAU_INV 10

#define CODE_CLE_POISSON_INV 11

///////////////////////////////////////////////////////

struct inventaire_s{
	int nbcode;
	int tabcode[NB_CODE_MAX];
	int nbcle;
	int tabcle[NB_CLE_MAX];
};
typedef struct inventaire_s inventaire_t;
