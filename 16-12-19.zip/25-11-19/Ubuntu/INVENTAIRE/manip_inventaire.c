#include "../GENERAL/general.h"

void lire_objet_affichage_inventaire_terminal(int code, int i){
	switch(i){
		case CODE_FIOLE_INV:
			printf("		FIOLE : %d\n" , code);
			break;
		case CODE_SNACK_INV:
			printf("		SNACK : %i\n" , code);
			break;
		case CODE_BONBON_INV:
			printf("		BONBON : %i\n" , code);
			break;
		case CODE_PILE_INV:
			printf("		PILE : %i\n" , code);
			break;
		case CODE_FROMAGE_INV:
			printf("		FROMAGE : %i\n" , code);
			break;
	}
}

void lire_cle_affichage_inventaire_terminal(int code, int i){
	switch(i){
		case CODE_CLE_BELIER_INV:
			printf("		BELIER : %i\n" , code);
			break;
		case CODE_CLE_TAUREAU_INV:
			printf("		TAUREAU : %i\n" , code);
			break;
		case CODE_CLE_GEMEAU_INV:
			printf("		GEMEAU : %i\n" , code);
			break;
		case CODE_CLE_CANCER_INV:
			printf("		CANCER : %i\n" , code);
			break;
		case CODE_CLE_LION_INV:
			printf("		LION : %i\n" , code);
			break;
		case CODE_CLE_VIERGE_INV:
			printf("		VIERGE : %i\n" , code);
			break;
		case CODE_CLE_BALNCE_INV:
			printf("		BALANCE : %i\n" , code);
			break;
		case CODE_CLE_SCORPION_INV:
			printf("		SCORPION : %i\n" , code);
			break;
		case CODE_CLE_SAGITAIRE_INV:
			printf("		SAGITAIRE : %i\n" , code);
			break;
		case CODE_CLE_CAPRICORNE_INV:
			printf("		CAPRICORNE : %i\n" , code);
			break;
		case CODE_CLE_VERSEAU_INV:
			printf("		VERSEAU : %i\n" , code);
			break;
		case CODE_CLE_POISSON_INV:
			printf("		POISSON : %i\n" , code);
			break;
	}
}

void affichage_inventaire_terminal(inventaire_t* inv){
	printf("INVENTAIRE :\n");
	printf("	CONTENUE :\n");
	int a;
	for(int i=0; i<5; i++){
		a = inv->tabcode[i];
		lire_objet_affichage_inventaire_terminal(a,i);
	}
	printf("	CLE :\n");
	for(int i=0; i<12; i++){
		lire_cle_affichage_inventaire_terminal(&inv->tabcle[i], i);
	}
}

///////////////////////////////////////////////////////

void ajout_element_inventaire_item(inventaire_t* inv, int CODE){
	inv->tabcode[CODE]++;
}

///////////////////////////////////////////////////////

void ajout_element_inventaire_cle(inventaire_t* inv, int CODE){
	inv->tabcle[CODE]++;
}
