#include "../JEU_GENERAL/GENERAL/general.h"

void init_souris_distributeur(souris_t* s){
	s->x = -100;
	s->y = -100;
	s->click_x = -100;
	s->click_y = -100;
}

////////////////////////////////////////////////////////////////////////////////////////////

void init_rouleau_distributeur_fiole_pv(rouleau_t* r){
	r->item_1 = SDL_LoadBMP("RESSOURCES/DISTRIB/boisson_de_vie.bmp");
	r->item_2 = SDL_LoadBMP("RESSOURCES/DISTRIB/boisson_de_vie.bmp");
	r->item_3 = SDL_LoadBMP("RESSOURCES/DISTRIB/boisson_de_vie.bmp");
	r->lequel = LEQUEL_FIOLE_DIST;
	r->a_faire_tomber = 0;
}

void init_rouleau_distributeur_snack_attaque(rouleau_t* r){
	r->item_1 = SDL_LoadBMP("RESSOURCES/DISTRIB/snack_attaque.bmp");
	r->item_2 = SDL_LoadBMP("RESSOURCES/DISTRIB/snack_attaque.bmp");
	r->item_3 = SDL_LoadBMP("RESSOURCES/DISTRIB/snack_attaque.bmp");
	r->lequel = LEQUEL_SNACK_DIST;
	r->a_faire_tomber = 0;
}

void init_rouleau_distributeur_bonbon_defence(rouleau_t* r){
	r->item_1 = SDL_LoadBMP("RESSOURCES/DISTRIB/Bonbon_defense.bmp");
	r->item_2 = SDL_LoadBMP("RESSOURCES/DISTRIB/Bonbon_defense.bmp");
	r->item_3 = SDL_LoadBMP("RESSOURCES/DISTRIB/Bonbon_defense.bmp");
	r->lequel = LEQUEL_BONBON_DIST;
	r->a_faire_tomber = 0;
}

void init_rouleau_distributeur_pile(rouleau_t* r){
	r->item_1 = SDL_LoadBMP("RESSOURCES/DISTRIB/pile.bmp");
	r->item_2 = SDL_LoadBMP("RESSOURCES/DISTRIB/pile.bmp");
	r->item_3 = SDL_LoadBMP("RESSOURCES/DISTRIB/pile.bmp");
	r->lequel = LEQUEL_PILE_DIST;
	r->a_faire_tomber = 0;
}

/////////////////////////////

void init_rouleau_distributeur(rouleau_t* r,int i){
	switch(i){
		case 1:
			init_rouleau_distributeur_snack_attaque(r);
			r->x = X_ROULEAU_1;
			r->y = Y_ROULEAU_1;
			break;
		case 2:
			init_rouleau_distributeur_fiole_pv(r);
			r->x = X_ROULEAU_2;
			r->y = Y_ROULEAU_1;
			break;
		case 3:
			init_rouleau_distributeur_pile(r);
			r->x = X_ROULEAU_3;
			r->y = Y_ROULEAU_1;
			break;
		case 4:
			init_rouleau_distributeur_bonbon_defence(r);
			r->x = X_ROULEAU_1;
			r->y = Y_ROULEAU_2 ;
			break;
		case 5:
			init_rouleau_distributeur_pile(r);
			r->x = X_ROULEAU_2;
			r->y = Y_ROULEAU_2;
			break;
		case 6:
			init_rouleau_distributeur_snack_attaque(r);
			r->x = X_ROULEAU_3;
			r->y = Y_ROULEAU_2;
			break;
		case 7:
			init_rouleau_distributeur_bonbon_defence(r);
			r->x = X_ROULEAU_1;
			r->y = Y_ROULEAU_3;
			break;
		case 8:
			init_rouleau_distributeur_snack_attaque(r);
			r->x = X_ROULEAU_2;
			r->y = Y_ROULEAU_3;
			break;
		case 9:
			init_rouleau_distributeur_fiole_pv(r);
			r->x = X_ROULEAU_3;
			r->y = Y_ROULEAU_3;
			break;
	}
	r->anneau = SDL_LoadBMP("RESSOURCES/DISTRIB/anneau.bmp");
}

////////////////////////////////////////////////////////////////////////////////////////////

void init_bouton_dist_fiole(bouton_dist_t* b){
	b->b1 = SDL_LoadBMP("RESSOURCES/DISTRIB/bouton_fiole.bmp");
	b->b2 = SDL_LoadBMP("RESSOURCES/DISTRIB/bouton_fiole_cliquable.bmp");
	b->sprite = b->b1;
	b->largeur = LARGEUR_BOUTON_DIST;
	b->hauteur = HAUTEUR_BOUTON_DIST;
	b->x = X_BOUTON_DIST;
	b->y = Y_BOUTON_DIST;
	b->lequel = LEQUEL_FIOLE_DIST;
}

void init_bouton_dist_snack(bouton_dist_t* b){
	b->b1 = SDL_LoadBMP("RESSOURCES/DISTRIB/bouton_snack.bmp");
	b->b2 = SDL_LoadBMP("RESSOURCES/DISTRIB/bouton_snack_cliquable.bmp");
	b->sprite = b->b1;
	b->largeur = LARGEUR_BOUTON_DIST;
	b->hauteur = HAUTEUR_BOUTON_DIST;
	b->x = X_BOUTON_DIST;
	b->y = Y_BOUTON_DIST + (ECART_BOUTON_DIST*1);
	b->lequel = LEQUEL_SNACK_DIST;
}

void init_bouton_dist_bonbon(bouton_dist_t* b){
	b->b1 = SDL_LoadBMP("RESSOURCES/DISTRIB/bouton_bonbon.bmp");
	b->b2 = SDL_LoadBMP("RESSOURCES/DISTRIB/bouton_bonbon_cliquable.bmp");
	b->sprite = b->b1;
	b->largeur = LARGEUR_BOUTON_DIST;
	b->hauteur = HAUTEUR_BOUTON_DIST;
	b->x = X_BOUTON_DIST;
	b->y = Y_BOUTON_DIST + (ECART_BOUTON_DIST*2);
	b->lequel = LEQUEL_BONBON_DIST;
}

void init_bouton_dist_pile(bouton_dist_t* b){
	b->b1 = SDL_LoadBMP("RESSOURCES/DISTRIB/bouton_pile.bmp");
	b->b2 = SDL_LoadBMP("RESSOURCES/DISTRIB/bouton_pile_cliquable.bmp");
	b->sprite = b->b1;
	b->largeur = LARGEUR_BOUTON_DIST;
	b->hauteur = HAUTEUR_BOUTON_DIST;
	b->x = X_BOUTON_DIST;
	b->y = Y_BOUTON_DIST + (ECART_BOUTON_DIST*3);
	b->lequel = LEQUEL_PILE_DIST;
}

void init_bouton_dist_achat(bouton_dist_t* b){
	b->b1 = SDL_LoadBMP("RESSOURCES/DISTRIB/bouton_achat.bmp");
	b->b2 = SDL_LoadBMP("RESSOURCES/DISTRIB/bouton_achat_cliquable.bmp");
	b->sprite = b->b1;
	b->largeur = LARGEUR_BOUTON_DIST;
	b->hauteur = HAUTEUR_BOUTON_DIST;
	b->x = X_BOUTON_DIST;
	b->y = Y_BOUTON_DIST + (ECART_BOUTON_DIST*4);
	b->lequel = LEQUEL_ACHAT_DIST;
}

void init_bouton_dist_retour(bouton_dist_t* b){
	b->b1 = SDL_LoadBMP("RESSOURCES/DISTRIB/bouton_retour.bmp");
	b->b2 = SDL_LoadBMP("RESSOURCES/DISTRIB/bouton_retour_cliquable.bmp");
	b->sprite = b->b1;
	b->largeur = LARGEUR_BOUTON_DIST;
	b->hauteur = HAUTEUR_BOUTON_DIST;
	b->x = X_BOUTON_DIST;
	b->y = Y_BOUTON_DIST + (ECART_BOUTON_DIST*5);
	b->lequel = LEQUEL_RETOUR_DIST;
}

/////////////////////////////

void init_bouton_distributeur(bouton_dist_t* b, int i){
	switch(i){
		case LEQUEL_FIOLE_DIST:
			init_bouton_dist_fiole(b);
			break;
		case LEQUEL_SNACK_DIST:
			init_bouton_dist_snack(b);
			break;
		case LEQUEL_BONBON_DIST:
			init_bouton_dist_bonbon(b);
			break;
		case LEQUEL_PILE_DIST:
			init_bouton_dist_pile(b);
			break;
		case LEQUEL_ACHAT_DIST:
			init_bouton_dist_achat(b);
			break;
		case LEQUEL_RETOUR_DIST:
			init_bouton_dist_retour(b);
			break;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////

void init_data_distributeur(distributeur_t* d){
	d->ouvert = true;
	d->selection = 0;
	d->fond = SDL_LoadBMP("RESSOURCES/DISTRIB/fond_distri.bmp");
	d->devant = SDL_LoadBMP("RESSOURCES/DISTRIB/devant_distri.bmp");

	d->achat_simple = SDL_LoadBMP("RESSOURCES/DISTRIB/achat_simple.bmp");
	d->achat_fiole = SDL_LoadBMP("RESSOURCES/DISTRIB/achat_fiole.bmp");
	d->achat_snack = SDL_LoadBMP("RESSOURCES/DISTRIB/achat_snack.bmp");
	d->achat_bonbon = SDL_LoadBMP("RESSOURCES/DISTRIB/achat_bonbon.bmp");
	d->achat_pile = SDL_LoadBMP("RESSOURCES/DISTRIB/achat_pile.bmp");
	d->achat_accepter = SDL_LoadBMP("RESSOURCES/DISTRIB/achat_accepter.bmp");
	d->achat_refuser = SDL_LoadBMP("RESSOURCES/DISTRIB/achat_refuser.bmp");
	d->achat = d->achat_simple;

	d->nbrouleau = NB_ROULEAU_DIST;
	for(int i = 0; i<d->nbrouleau; i++){
		init_rouleau_distributeur(&d->tabrouleau[i],i+1);
	}
	d->nbbouton = NB_BOUTON_DIST_MAX;
	for(int i = 0; i<d->nbbouton; i++){
		init_bouton_distributeur(&d->tabbouton[i],i+1);
	}
	init_souris_distributeur(&d->souris);
}


