/**
* \file init_fuir.h
* \brief Module d'inititialisation
* \author 
* \version 0.1
* \date 
*/

#ifndef INIT_DISTRIBUTEUR_H
#define INIT_DISTRIBUTEUR_H

#include "../JEU_GENERAL/GENERAL/sdl-light.h"

void init_souris_distributeur(souris_t* s);

////////////////////////////////////////////////////////////////////////////////////////////

void init_rouleau_distributeur_fiole_pv(rouleau_t* r);

void init_rouleau_distributeur_snack_attaque(rouleau_t* r);

void init_rouleau_distributeur_bonbon_defence(rouleau_t* r);

void init_rouleau_distributeur_pile(rouleau_t* r);

/////////////////////////////

void init_rouleau_distributeur(rouleau_t* r,int i);

////////////////////////////////////////////////////////////////////////////////////////////

void init_bouton_dist_fiole(bouton_dist_t* b);

void init_bouton_dist_snack(bouton_dist_t* b);

void init_bouton_dist_bonbon(bouton_dist_t* b);

void init_bouton_dist_pile(bouton_dist_t* b);

void init_bouton_dist_achat(bouton_dist_t* b);

void init_bouton_dist_retour(bouton_dist_t* b);

/////////////////////////////

void init_bouton_distributeur(bouton_dist_t* b, int i);

////////////////////////////////////////////////////////////////////////////////////////////

void init_data_distributeur(distributeur_t* d);

#endif
