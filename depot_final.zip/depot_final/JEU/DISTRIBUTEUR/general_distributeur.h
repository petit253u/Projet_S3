/**
* \file general_fuir.h
* \brief Module de structure et constante
* \author 
* \version 0.1
* \date 
*/

#include "../JEU_GENERAL/GENERAL/sdl-light.h"
#include <stdbool.h> 

///////////////////////////////////////////////////////

#define NB_ROULEAU_DIST 9

///////

#define Y_ROULEAU_1 -20

#define Y_ROULEAU_2 215

#define Y_ROULEAU_3 442

///////

#define X_ROULEAU_1 50

#define X_ROULEAU_2 305

#define X_ROULEAU_3 551

//////////////

#define NB_BOUTON_DIST_MAX 6

#define LARGEUR_BOUTON_DIST 150

#define HAUTEUR_BOUTON_DIST 60

#define X_BOUTON_DIST 820

#define Y_BOUTON_DIST 235

#define ECART_BOUTON_DIST 65

//////////////

#define LEQUEL_SIMPLE_DIST 0

#define LEQUEL_FIOLE_DIST 1

#define LEQUEL_SNACK_DIST 2

#define LEQUEL_BONBON_DIST 3

#define LEQUEL_PILE_DIST 4

#define LEQUEL_ACHAT_DIST 5

#define LEQUEL_RETOUR_DIST 6

#define LEQUEL_REFUSER_DIST 7

#define LEQUEL_ACCEPTER_DIST 8

//////////////

#define X_ECRAN_ACHAT 812

#define Y_ECRAN_ACHAT 68

///////////////////////////////////////////////////////

struct rouleau_s{
	SDL_Surface* item_1;
	SDL_Surface* item_2;
	SDL_Surface* item_3;
	SDL_Surface* anneau;
	int x;
	int y;
	int lequel; //1 : FIOLE ; 2 : SNACK ; 3 : BONBON ; 4 : PILE ;
	int a_faire_tomber;
};
typedef struct rouleau_s rouleau_t;

struct bouton_dist_s{
	SDL_Surface* sprite;
	SDL_Surface* b1;
	SDL_Surface* b2;
	int x;
	int y;
	int largeur;
	int hauteur;
	int lequel; //1 : FIOLE ; 2 : SNACK ; 3 : BONBON ; 4 : PILE ; 5 : ACHAT ; 6 : RETOUR ;
};
typedef struct bouton_dist_s bouton_dist_t;


struct distributeur_s{
	bool ouvert; //true : distributeur ouvert ; false : distributeur fermé
	SDL_Surface* fond;
	SDL_Surface* devant;

	SDL_Surface* achat_simple;
	SDL_Surface* achat_fiole;
	SDL_Surface* achat_snack;
	SDL_Surface* achat_bonbon;
	SDL_Surface* achat_pile;
	SDL_Surface* achat_accepter;
	SDL_Surface* achat_refuser;
	SDL_Surface* achat;

	int selection; //0 : RIEN ; 1 : FIOLE ; 2 : SNACK ; 3 : BONBON ; 4 : PILE ;
	int nbrouleau;
	rouleau_t tabrouleau[NB_ROULEAU_DIST];
	int nbbouton;
	bouton_dist_t tabbouton[NB_BOUTON_DIST_MAX];
	souris_t souris;
};
typedef struct distributeur_s distributeur_t;

