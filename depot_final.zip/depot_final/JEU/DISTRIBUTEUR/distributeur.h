#ifndef DISTRIBUTEUR_H
#define DISTRIBUTEUR_H

#include "../JEU_GENERAL/GENERAL/sdl-light.h"

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void refresh_graphics_rouleau_distributeur(SDL_Surface *ecran,rouleau_t* r);

void refresh_graphics_bouton_distributeur(SDL_Surface *ecran,bouton_dist_t* b);

void refresh_graphics_dis(SDL_Surface *ecran, distributeur_t* d);

///////////////////////////////////////////////////////////////////////////////////////////////////////////

void refresh_affichage_particulier_rouleau(SDL_Surface *ecran,rouleau_t* r, int yitem, int xrouleau, int yrouleau);

void refresh_affichage_particulier(SDL_Surface *ecran, distributeur_t* d, int yitem, int xrouleau, int yrouleau);

////////////////////////

void affichage_fiole_tombe(world_t *world, SDL_Surface *ecran);

void affichage_snack_tombe(world_t *world, SDL_Surface *ecran);

void affichage_bonbon_tombe(world_t *world, SDL_Surface *ecran);

void affichage_pile_tombe(world_t *world, SDL_Surface *ecran);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void update_sprite_achat(distributeur_t* d, int lequel);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void lecture_achat_fiole(world_t *world, SDL_Surface *ecran);

void lecture_achat_snack(world_t *world, SDL_Surface *ecran);

void lecture_achat_bonbon(world_t *world, SDL_Surface *ecran);

void lecture_achat_pile(world_t *world, SDL_Surface *ecran);

void verif_achat(world_t *world, SDL_Surface *ecran);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void lire_bouton(bouton_dist_t* b, world_t *world, SDL_Surface *ecran);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void verif_click_bouton_dis(bouton_dist_t* b, souris_t* s, world_t *world, SDL_Surface *ecran);

void verif_click_dis(distributeur_t* d, world_t *world, SDL_Surface *ecran);

/////////////////////////////////

void verif_pos_bouton_dis(bouton_dist_t* b, souris_t* s);

void verif_pos_dis(distributeur_t* d);

/////////////////////////////////

void verif_dis(distributeur_t* d, world_t *world, SDL_Surface *ecran);

/////////////////////////////////

void handle_event_dis(SDL_Event *event, world_t* world);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void init_graphics_rouleau_distributeur(SDL_Surface *ecran,rouleau_t* r);

void init_graphics_bouton_distributeur(SDL_Surface *ecran,bouton_dist_t* b);

void init_graphics_distributeur(SDL_Surface *ecran, distributeur_t* d );

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void boucle_distributeur(world_t *world,SDL_Surface *ecran);

#endif
