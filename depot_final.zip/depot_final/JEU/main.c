/**
* \file main.c
* \brief Programme principal du jeu
* \author 
* \version 0.1
* \date 
*/
#include <stdio.h> 
#include <stdlib.h> 
#include <time.h>
#include <stddef.h> 
#include <math.h>

#include "JEU_GENERAL/GENERAL/sdl-light.h"
#include "JEU_GENERAL/GENERAL/general.h"


/**
*  \brief programme principal qui implémente la boucle du jeu
*/
int main( int argc, char* args[] )
{
	world_t world;
	srand(time(NULL));
	boucle_jeu(&world);
	return 0;
}
