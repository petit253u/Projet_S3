/**
* \file update.c
* \brief Module d'update
* \author 
* \version 0.1
* \date 
*/

#ifndef JEU_GENERAL_H
#define JEU_GENERAL_H

#include "GENERAL/sdl-light.h"

void init_graphics(SDL_Surface *ecran, world_t *world);

void clean_data(world_t *world);

int is_game_over(world_t *world);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void libere_jeu(world_t *world);

void boucle_jeu(world_t *world);

#endif


