/**
* \file update.c
* \brief Module d'update
* \author 
* \version 0.1
* \date 
*/

#ifndef INIT_GENERAL_H
#define INIT_GENERAL_H

#include "sdl-light.h"

void init_souris(souris_t* s);

void init_temps(temps_t* t, int ecart);

void init_bouton(bouton_t* b, int x, int y, int largeur, int hauteur, int code);

void init_data(world_t* world);

void update_click_souris(souris_t *souris, int x, int y);

void update_pos_souris(souris_t *souris, int x, int y);

#endif


