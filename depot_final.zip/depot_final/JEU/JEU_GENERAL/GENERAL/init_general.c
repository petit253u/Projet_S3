/**
* \file update.c
* \brief Module d'update
* \author 
* \version 0.1
* \date 
*/

#include "general.h"

void init_souris(souris_t* s){
	s->x = -100;
	s->y = -100;
	s->click_x = -100;
	s->click_x = -100;
}

void init_temps(temps_t* t, int ecart){
	t->ecart_souhait = ecart;
	t->temps_ancien = SDL_GetTicks();
	t->temps_actuel = SDL_GetTicks();
}

void init_bouton(bouton_t* b, int x, int y, int largeur, int hauteur, int code){
	b->x = x;
	b->y = y;
	b->largeur = largeur;
	b->hauteur = hauteur;
	b->code = code;
}

void init_data(world_t* world){
	world->gameover = 0;
	world->background = load_image("RESSOURCES/FONDNIVEAU.bmp"); 
}

//////////////////////////////////////////////////////////////////////////////////

void update_click_souris(souris_t *souris, int x, int y){
	souris->click_x = x;
	souris->click_y = y;
}

void update_pos_souris(souris_t *souris, int x, int y){
	souris->x = x;
	souris->y = y;	
}
