/**
* \file general.h
* \brief Module de structure et constante
* \author 
* \version 0.1
* \date 
*/

///////////////////////////////////////////////////////

#include "sdl-light.h"
#include <stdbool.h> 

/**
* \brief Largeur de l'écran de jeu
*/
#define SCREEN_WIDTH 1000

/**
* \brief Hauteur de l'écran de jeu
*/
#define SCREEN_HEIGHT 650

/**
* \brief Constante PI
*/
#define PI 3.14159265358979224

///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
///////////////////////////////////////////////////////

/**
* \brief Représentation du timer
*/
struct temps_s{
	int temps_ancien;
	int temps_actuel;
	int ecart_souhait;
};
typedef struct temps_s temps_t;

/**
* \brief Représentation de la souris 
*/
struct souris_s{
	int x;
	int y;
	int click_x;
	int click_y;	
};
typedef struct souris_s souris_t;

/**
* \brief Représentation d'un bouton
*/
struct bouton_s{
	int x;
	int y;
	int largeur;
	int hauteur;
	SDL_Surface* sprite;
	SDL_Surface* s1;
	SDL_Surface* s2;
	int code;
};
typedef struct bouton_s bouton_t;

#include "../../MENU/NAVIG/general_navig.h"
#include "../../MENU/MENU_DEPART/general_menu_demarrer.h"
#include "../../GAME/DEVINE_CARTE/general_fuir.h"
#include "../../GAME/COLOR_MEMORY/general_devine_couleur.h"
#include "../../AMELIORATION/general_amelio.h"
#include "../../DISTRIBUTEUR/general_distributeur.h"
#include "../../MENU/TEST/general_test.h"

//////////////////////////////////////////////////////////////////////////

/**
* \brief Représentation du monde du jeu
*/
struct world_s{
	int gameover;
	SDL_Surface* background;
	navig_t navig;
	fuir_t fuir;
	devine_couleur_t dc;
	distributeur_t dis;
	amelioration_t amelio;
	menu_entree_t debut;
	test_t test;

};
typedef struct world_s world_t;


