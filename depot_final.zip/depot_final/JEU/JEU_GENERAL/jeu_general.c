/**
* \file update.c
* \brief Module d'update
* \author 
* \version 0.1
* \date 
*/

#include "GENERAL/general.h"

void init_graphics(SDL_Surface *ecran, world_t *world){
	return;
}

/**
* \brief La fonction nettoie les données du monde
* \param world les données du monde
*/


void clean_data(world_t *world){

}

/**
* \brief La fonction indique si le jeu est fini en fonction des données du monde
* \param world les données du monde
* \return 1 si le jeu est fini, 0 sinon
*/

int is_game_over(world_t *world){
	return world->gameover;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void libere_jeu(world_t *world){
	printf("BOUCLE VIDANGE :\n");
	clean_data(world);
	quit_sdl();
	return;
}

void boucle_jeu(world_t *world){
	printf("BOUCLE JEU :\n");

	SDL_Event event;
	SDL_Surface *screen;

	screen = init_sdl(SCREEN_WIDTH, SCREEN_HEIGHT);

	 menu_jeu(world,screen);

	printf("	INIT_WORLD :\n");
	init_data(world);
	printf("	INIT_GRAPH :\n");
	init_graphics(screen,world);

	SDL_EnableKeyRepeat(100,100);

	while(!is_game_over(world)){
		boucle_navig(world, screen);
	}
	libere_jeu(world);
	return;
}






