/**
* \file general_fuir.h
* \brief Module de structure et constante
* \author 
* \version 0.1
* \date 
*/

#include "../JEU_GENERAL/GENERAL/sdl-light.h"
#include <stdbool.h> 

///////////////////////////////////////////////////////

#define NB_AMELIO_MAX 3

#define LARGEUR_BOUTON_AMELIO 250

#define HAUTEUR_BOUTON_AMELIO 350

//////////////////////

#define X_BOUTON_AMELIO_1 30

#define Y_BOUTON_AMELIO_1 150

#define X_BOUTON_AMELIO_2 375

#define Y_BOUTON_AMELIO_2 120

#define X_BOUTON_AMELIO_3 720

#define Y_BOUTON_AMELIO_3 150

///////////////////////////////////////////////////////

#define LEQUEL_PV_AMELIO 1

#define LEQUEL_DEFENSE_AMELIO 2

#define LEQUEL_ATTAQUE_AMELIO 3

///////////////////////////

#define AMELIO_PV_RES 10 //pv max + 10 

#define AMELIO_DEFENSE_RES 5 // defense permanente + 5 

#define AMELIO_ATTAQUE_RES 5 // degat + 5

///////////////////////////////////////////////////////

struct bouton_amelio_s{
	SDL_Surface* sprite;
	SDL_Surface* b1;
	SDL_Surface* b2;
	int x;
	int y;
	int largeur;
	int hauteur;
	int lequel;//1 : PV ; 2 : BOUCLIER ; 3 : ATTAQUE ; 
};
typedef struct bouton_amelio_s bouton_amelio_t;

struct amelioration_s{
	bool ouvert;
	SDL_Surface* fond;
	int nbamelio;
	bouton_amelio_t tabamelio[3];
	souris_t souris;
};
typedef struct amelioration_s amelioration_t;
