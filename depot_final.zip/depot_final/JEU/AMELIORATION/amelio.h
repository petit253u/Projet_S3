/**
* \file init_fuir.h
* \brief Module d'inititialisation
* \author 
* \version 0.1
* \date 
*/

#ifndef AMELIO_H
#define AMELIO_H

#include "../JEU_GENERAL/GENERAL/sdl-light.h"

///////////////////////////////////////////////////////////////////////////////////////////////////////////

void refresh_graphics_bouton_amelio(SDL_Surface *ecran,bouton_amelio_t* b);

void refresh_graphics_amelio(SDL_Surface *ecran, amelioration_t* a);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void lire_bouton_amelio(bouton_amelio_t* b, world_t *world, SDL_Surface *ecran);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void verif_click_bouton_amelio(bouton_amelio_t* b, souris_t* s, world_t *world, SDL_Surface *ecran);

void verif_click_amelio(amelioration_t* a, world_t *world, SDL_Surface *ecran);

/////////////////////////////////

void verif_pos_bouton_amelio(bouton_amelio_t* b, souris_t* s);

void verif_pos_amelio(amelioration_t* a);

/////////////////////////////////

void verif_amelio(amelioration_t* a, world_t *world, SDL_Surface *ecran);

/////////////////////////////////

void handle_event_amelio(SDL_Event *event, world_t* world);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void init_graphics_bouton_amelio(SDL_Surface *ecran,bouton_amelio_t* b);

void  init_graphics_amelio(SDL_Surface *ecran, amelioration_t* a );

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void boucle_amelio(world_t *world,SDL_Surface *ecran);

#endif
