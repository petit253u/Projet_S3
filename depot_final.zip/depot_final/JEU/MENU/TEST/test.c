#include "../../JEU_GENERAL/GENERAL/general.h"

void handle_event_test(SDL_Event *event, world_t *world){
	int mouseX, mouseY;
	while( SDL_PollEvent( event ) ) {
		//Si l'utilisateur a cliqué sur le X de la fenêtre
		if( event->type == SDL_QUIT ) {
			//On quitte le programme
			world->gameover = 1;
			world->navig.ouvert = false;
			world->test.ouvert = false;
		}
		/* Si l'utilisateur appuie sur
		la touche droite de la souris */
		if( event->type == SDL_MOUSEBUTTONDOWN){
			printf("CLICK\n");
              		SDL_GetMouseState(&mouseX, &mouseY);
			update_click_souris(&world->test.souris, mouseX, mouseY);
		}
		if( event->type == SDL_MOUSEMOTION){
			printf("BOUGE\n");
			SDL_GetMouseState(&mouseX, &mouseY);
			update_pos_souris(&world->test.souris, mouseX, mouseY);
		}
	}
} 

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void init_graphics_bouton_test(SDL_Surface *ecran, bouton_t* b){
	set_transparence(ecran, b->s1, 255, 0, 255);
	set_transparence(ecran, b->s2, 255, 0, 255);
}

void init_graphics_test(SDL_Surface *ecran, test_t *n){
	for(int i=0; i<n->nb_bouton; i++){
		init_graphics_bouton_test(ecran,&n->tab_bouton[i]);
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void refresh_graphics_bouton_test(SDL_Surface *ecran, bouton_t* b){
	apply_surface(b->sprite,ecran, b->x,b->y);
}

void refresh_graphics_test(SDL_Surface *ecran, test_t *navig){
	apply_surface(navig->fond,ecran, 0,-15);
	for(int i=0; i<navig->nb_bouton; i++){
		refresh_graphics_bouton_navig(ecran,&navig->tab_bouton[i]);
	}
	refresh_surface(ecran);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void lire_bouton_test(world_t *world,SDL_Surface *ecran, int i){
	switch(i){
		case LEQUEL_BOUTON_TEST_1:
			boucle_amelio(world,ecran);
			break;
		case LEQUEL_BOUTON_TEST_2:
			boucle_distributeur(world,ecran);
			break;
		case LEQUEL_BOUTON_TEST_RETOUR:
			world->test.ouvert = false;
			break;
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void verif_click_test(bouton_t* b,souris_t* s,world_t *world,SDL_Surface *ecran,int i){
	if((s->click_x >= b->x) && (s->click_x <= b->x + b->largeur)){
		if((s->click_y >= b->y) && (s->click_y <= b->y + b->hauteur)){
			lire_bouton_test(world,ecran,i);
			
			s->click_x = -100;
			s->click_y = -100;
		}
	}
}

/////////////////////////

void verif_pos_test(bouton_t* b,souris_t* s){
	if((s->x >= b->x) && (s->x <= b->x + b->largeur)){
		if((s->y >= b->y) && (s->y <= b->y + b->hauteur)){
			b->sprite = b->s2;
			return;
		}
	}
	b->sprite = b->s1;
}

/////////////////////////

void verif_test(world_t *world,SDL_Surface *ecran){
	for(int i=0; i<world->test.nb_bouton; i++){
		verif_pos_test(&world->test.tab_bouton[i],&world->test.souris);
		verif_click_test(&world->test.tab_bouton[i],&world->test.souris,world,ecran,i+1);
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

int boucle_test(world_t *world,SDL_Surface *ecran){
	printf("	NAVIG:\n");
	SDL_Event event_test;
	init_data_test(&world->test);
	init_graphics_test(ecran,&world->test);
	SDL_EnableKeyRepeat(100,100);	
	while(world->test.ouvert == true){
		handle_event_test(&event_test, world);
		verif_test(world,ecran);
		refresh_graphics_test(ecran,&world->test);
	}
}
