/**
* \file init_fuir.h
* \brief Module d'inititialisation
* \author 
* \version 0.1
* \date 
*/

#ifndef INIT_TEST_H
#define INIT_TEST_H

#include "../../JEU_GENERAL/GENERAL/sdl-light.h"

void init_data_bouton_test(bouton_t* b, int code);

void init_data_test(test_t* n);

#endif
