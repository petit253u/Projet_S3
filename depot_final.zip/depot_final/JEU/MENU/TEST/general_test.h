/**
* \file general_fuir.h
* \brief Module de structure et constante
* \author 
* \version 0.1
* \date 
*/

#include "../../JEU_GENERAL/GENERAL/sdl-light.h"
#include <stdbool.h> 

///////////////////////////////////////////////////////

#define NB_BOUTON_MAX_TEST 3

#define HAUTEUR_BOUTON_TEST 150

#define LARGEUR_BOUTON_TEST 300

////////////////////

#define LEQUEL_BOUTON_TEST_1 1

#define LEQUEL_BOUTON_TEST_2 2

#define LEQUEL_BOUTON_TEST_RETOUR 3

////////////////////

#define X_BOUTON_TEST_LIGNE_1 30

#define X_BOUTON_TEST_LIGNE_2 670

#define X_BOUTON_TEST_LIGNE_3 350

////////////////////

#define Y_BOUTON_TEST_LIGNE_1 200

#define Y_BOUTON_TEST_LIGNE_2 425

///////////////////////////////////////////////////////

struct test_s{
	bool ouvert; //true : menu ouvert ; false : menu fermé
	SDL_Surface* fond;
	int nb_bouton;
	bouton_t tab_bouton[NB_BOUTON_MAX_NAVIG];
	int lequel; 
	souris_t souris;
};
typedef struct test_s test_t;

