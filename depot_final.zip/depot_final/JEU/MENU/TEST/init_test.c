#include "../../JEU_GENERAL/GENERAL/general.h"

void init_data_bouton_test(bouton_t* b, int code){
	switch(code){
		case LEQUEL_BOUTON_TEST_1:
			init_bouton(b, X_BOUTON_TEST_LIGNE_1, Y_BOUTON_TEST_LIGNE_1, LARGEUR_BOUTON_TEST, HAUTEUR_BOUTON_TEST, code);
			b->s1 = load_image("RESSOURCES/NAVIG/4-2.bmp");
			b->s2 = load_image("RESSOURCES/NAVIG/4-2_click.bmp");
			break;
		case LEQUEL_BOUTON_TEST_2:
			init_bouton(b, X_BOUTON_TEST_LIGNE_2, Y_BOUTON_TEST_LIGNE_1, LARGEUR_BOUTON_TEST, HAUTEUR_BOUTON_TEST, code);
			b->s1 = load_image("RESSOURCES/NAVIG/3-2.bmp");
			b->s2 = load_image("RESSOURCES/NAVIG/3-2_click.bmp");
			break;
		case LEQUEL_BOUTON_TEST_RETOUR:
			init_bouton(b, X_BOUTON_TEST_LIGNE_3, Y_BOUTON_TEST_LIGNE_2, LARGEUR_BOUTON_TEST, HAUTEUR_BOUTON_TEST, code);
			b->s1 = load_image("RESSOURCES/NAVIG/6-2.bmp");
			b->s2 = load_image("RESSOURCES/NAVIG/6-2_click.bmp");
			break;
	}
	b->sprite = b->s1;
}

void init_data_test(test_t* n){
	n->ouvert = true;
	n->fond =  load_image("RESSOURCES/FONDAREA.bmp");
	n->lequel = 0;
	n->nb_bouton = NB_BOUTON_MAX_TEST;
	for(int i = 0; i<n->nb_bouton; i++){
		init_data_bouton_test(&n->tab_bouton[i],i+1);
	}
	init_souris(&n->souris);
}
