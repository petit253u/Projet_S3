#include "../../JEU_GENERAL/GENERAL/general.h"

void init_data_debut(menu_entree_t* debut){
	debut->bouton.s1 = SDL_LoadBMP("RESSOURCES/DEPART/bouton_jouer.bmp");
	debut->bouton.s2 = SDL_LoadBMP( "RESSOURCES/DEPART/bouton_jouer_cliquable.bmp" );
	debut->bouton.sprite = debut->bouton.s1;
	init_bouton(&debut->bouton,X_BOUTON_MENU,Y_BOUTON_MENU,LARGEUR_BOUTON_MENU,HAUTEUR_BOUTON_MENU,0);
	debut->ouvert = true;
	debut->fond = SDL_LoadBMP("RESSOURCES/FONDTITRE.bmp");
	init_souris(&debut->souris);
}

