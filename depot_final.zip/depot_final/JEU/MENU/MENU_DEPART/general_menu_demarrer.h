/**
* \file general_fuir.h
* \brief Module de structure et constante
* \author 
* \version 0.1
* \date 
*/

#include "../../JEU_GENERAL/GENERAL/sdl-light.h"
#include <stdbool.h> 

///////////////////////////////////////////////////////

#define HAUTEUR_BOUTON_MENU 600

#define LARGEUR_BOUTON_MENU 600

////////////////////

#define X_BOUTON_MENU 200

////////////////////

#define Y_BOUTON_MENU 25

///////////////////////////////////////////////////////

struct menu_entree_s{
	bool ouvert; //true : menu ouvert ; false : menu fermé
	SDL_Surface* fond;
	bouton_t bouton;
	souris_t souris;
};
typedef struct menu_entree_s menu_entree_t;
