#include "../../JEU_GENERAL/GENERAL/general.h"
void handle_event_debut(SDL_Event *event, world_t *world){
	int mouseX, mouseY;
	while( SDL_PollEvent( event ) ) {
		//Si l'utilisateur a cliqué sur le X de la fenêtre
		if( event->type == SDL_QUIT ) {
			//On quitte le programme
			world->gameover = 1;
			world->debut.ouvert = false;
		}
		/* Si l'utilisateur appuie sur
		la touche droite de la souris */
		if( event->type == SDL_MOUSEBUTTONDOWN){
			printf("CLICK\n");
              		SDL_GetMouseState(&mouseX, &mouseY);
			update_click_souris(&world->debut.souris, mouseX, mouseY);
		}
		if( event->type == SDL_MOUSEMOTION){
			printf("BOUGE\n");
			SDL_GetMouseState(&mouseX, &mouseY);
			update_pos_souris(&world->debut.souris, mouseX, mouseY);
		}
	}
} 

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void init_graphics_debut(SDL_Surface *ecran, menu_entree_t *d){
	set_transparence(ecran, d->bouton.s1, 255, 0, 255);
	set_transparence(ecran, d->bouton.s2, 255, 0, 255);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void refresh_graphics_debut(SDL_Surface *ecran, menu_entree_t *d){
	apply_surface(d->fond,ecran, 0,0);
	apply_surface(d->bouton.sprite,ecran, d->bouton.x, d->bouton.y);
	refresh_surface(ecran);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void verif_click_debut(bouton_t* b,souris_t* s,world_t* world){
	if((s->click_x >= b->x) && (s->click_x <= b->x + b->largeur)){
		if((s->click_y >= b->y+ 350) && (s->click_y <= b->y + b->hauteur-90)){
			world->debut.ouvert = false;
			s->click_x = -100;
			s->click_y = -100;
		}
	}
}

/////////////////////////

void verif_pos_debut(bouton_t* b,souris_t* s){
	if((s->x >= b->x) && (s->x <= b->x + b->largeur)){
		if((s->y >= b->y + 350) && (s->y <= b->y + b->hauteur -90)){
			b->sprite = b->s2;
			return;
		}
	}
	b->sprite = b->s1;
}

/////////////////////////

void verif_debut(world_t *world){
	verif_pos_debut(&world->debut.bouton,&world->debut.souris);
	verif_click_debut(&world->debut.bouton,&world->debut.souris,world);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void menu_jeu(world_t* world, SDL_Surface* ecran){
	printf("BOUCLE MENU DEPART :\n");

	SDL_Event event0;
	init_data_debut(&world->debut);
	printf("BOUCLE MENU DEPART :\n");
	init_graphics_debut(ecran, &world->debut);
	printf("BOUCLE MENU DEPART :\n");
	SDL_EnableKeyRepeat(20,20);
	while(world->debut.ouvert == true){
		handle_event_debut(&event0, world);
		verif_debut(world);
		refresh_graphics_debut(ecran,&world->debut);
	}
}

