/**
* \file general_fuir.h
* \brief Module de structure et constante
* \author 
* \version 0.1
* \date 
*/

#include "../../JEU_GENERAL/GENERAL/sdl-light.h"
#include <stdbool.h> 

///////////////////////////////////////////////////////

#define NB_BOUTON_MAX_NAVIG 4

#define HAUTEUR_BOUTON_NAVIG 150

#define LARGEUR_BOUTON_NAVIG 300

////////////////////

#define LEQUEL_BOUTON_NAVIG_1 1

#define LEQUEL_BOUTON_NAVIG_2 2

#define LEQUEL_BOUTON_NAVIG_RETOUR 3

#define LEQUEL_BOUTON_NAVIG_TEST_AREA 4

////////////////////

#define X_BOUTON_NAVIG_LIGNE_1 150

#define X_BOUTON_NAVIG_LIGNE_2 550

////////////////////

#define Y_BOUTON_NAVIG_LIGNE_1 125

#define Y_BOUTON_NAVIG_LIGNE_2 375

///////////////////////////////////////////////////////

struct navig_s{
	bool ouvert; //true : menu ouvert ; false : menu fermé
	SDL_Surface* fond;
	int nb_bouton;
	bouton_t tab_bouton[NB_BOUTON_MAX_NAVIG];
	int lequel; 
	souris_t souris;
};
typedef struct navig_s navig_t;

