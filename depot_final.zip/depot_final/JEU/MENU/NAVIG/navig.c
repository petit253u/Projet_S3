#include "../../JEU_GENERAL/GENERAL/general.h"

void handle_event_navig(SDL_Event *event, world_t *world){
	int mouseX, mouseY;
	while( SDL_PollEvent( event ) ) {
		//Si l'utilisateur a cliqué sur le X de la fenêtre
		if( event->type == SDL_QUIT ) {
			//On quitte le programme
			world->gameover = 1;
			world->navig.ouvert = false;
		}
		/* Si l'utilisateur appuie sur
		la touche droite de la souris */
		if( event->type == SDL_MOUSEBUTTONDOWN){
			printf("CLICK\n");
              		SDL_GetMouseState(&mouseX, &mouseY);
			update_click_souris(&world->navig.souris, mouseX, mouseY);
		}
		if( event->type == SDL_MOUSEMOTION){
			printf("BOUGE\n");
			SDL_GetMouseState(&mouseX, &mouseY);
			update_pos_souris(&world->navig.souris, mouseX, mouseY);
		}
	}
} 

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void init_graphics_bouton_navig(SDL_Surface *ecran, bouton_t* b){
	set_transparence(ecran, b->s1, 255, 0, 255);
	set_transparence(ecran, b->s2, 255, 0, 255);
}

void init_graphics_navig(SDL_Surface *ecran, navig_t *n){
	for(int i=0; i<n->nb_bouton; i++){
		init_graphics_bouton_navig(ecran,&n->tab_bouton[i]);
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void refresh_graphics_bouton_navig(SDL_Surface *ecran, bouton_t* b){
	apply_surface(b->sprite,ecran, b->x,b->y);
}

void refresh_graphics_navig(SDL_Surface *ecran, navig_t *navig){
	apply_surface(navig->fond,ecran, 0,0);
	for(int i=0; i<navig->nb_bouton; i++){
		refresh_graphics_bouton_navig(ecran,&navig->tab_bouton[i]);
	}
	refresh_surface(ecran);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void lire_bouton_navig(world_t *world,SDL_Surface *ecran, int i){
	switch(i){
		case LEQUEL_BOUTON_NAVIG_1:
			boucle_fuir(world,ecran);
			break;
		case LEQUEL_BOUTON_NAVIG_2:
			boucle_devine_couleur(world,ecran);
			break;
		case LEQUEL_BOUTON_NAVIG_RETOUR:
			world->navig.ouvert = false;
			world->gameover = 1;
			break;
		case LEQUEL_BOUTON_NAVIG_TEST_AREA:
			boucle_test(world,ecran);
			break;
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void verif_click_navig(bouton_t* b,souris_t* s,world_t *world,SDL_Surface *ecran,int i){
	if((s->click_x >= b->x) && (s->click_x <= b->x + b->largeur)){
		if((s->click_y >= b->y) && (s->click_y <= b->y + b->hauteur)){
			lire_bouton_navig(world,ecran,i);
			
			s->click_x = -100;
			s->click_y = -100;
		}
	}
}

/////////////////////////

void verif_pos_navig(bouton_t* b,souris_t* s){
	if((s->x >= b->x) && (s->x <= b->x + b->largeur)){
		if((s->y >= b->y) && (s->y <= b->y + b->hauteur)){
			b->sprite = b->s2;
			return;
		}
	}
	b->sprite = b->s1;
}

/////////////////////////

void verif_navig(world_t *world,SDL_Surface *ecran){
	for(int i=0; i<world->navig.nb_bouton; i++){
		verif_pos_navig(&world->navig.tab_bouton[i],&world->navig.souris);
		verif_click_navig(&world->navig.tab_bouton[i],&world->navig.souris,world,ecran,i+1);
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

int boucle_navig(world_t *world,SDL_Surface *ecran){
	printf("	NAVIG:\n");
	SDL_Event event_navig;
	init_data_navig(&world->navig);
	init_graphics_navig(ecran,&world->navig);
	SDL_EnableKeyRepeat(100,100);	
	while(world->navig.ouvert == true){
		handle_event_navig(&event_navig, world);
		verif_navig(world,ecran);
		refresh_graphics_navig(ecran,&world->navig);
	}
}
