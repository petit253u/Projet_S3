#include "../../JEU_GENERAL/GENERAL/general.h"

void init_data_bouton_navig(bouton_t* b, int code){
	switch(code){
		case LEQUEL_BOUTON_NAVIG_1:
			init_bouton(b, X_BOUTON_NAVIG_LIGNE_1, Y_BOUTON_NAVIG_LIGNE_1, LARGEUR_BOUTON_NAVIG, HAUTEUR_BOUTON_NAVIG, code);
			b->s1 = load_image("RESSOURCES/NAVIG/1-2.bmp");
			b->s2 = load_image("RESSOURCES/NAVIG/1-2_click.bmp");
			break;
		case LEQUEL_BOUTON_NAVIG_2:
			init_bouton(b, X_BOUTON_NAVIG_LIGNE_2, Y_BOUTON_NAVIG_LIGNE_1, LARGEUR_BOUTON_NAVIG, HAUTEUR_BOUTON_NAVIG, code);
			b->s1 = load_image("RESSOURCES/NAVIG/2-2.bmp");
			b->s2 = load_image("RESSOURCES/NAVIG/2-2_click.bmp");
			break;
		case LEQUEL_BOUTON_NAVIG_RETOUR:
			init_bouton(b, X_BOUTON_NAVIG_LIGNE_1, Y_BOUTON_NAVIG_LIGNE_2, LARGEUR_BOUTON_NAVIG, HAUTEUR_BOUTON_NAVIG, code);
			b->s1 = load_image("RESSOURCES/NAVIG/6-2.bmp");
			b->s2 = load_image("RESSOURCES/NAVIG/6-2_click.bmp");
			break;
		case LEQUEL_BOUTON_NAVIG_TEST_AREA:
			init_bouton(b, X_BOUTON_NAVIG_LIGNE_2, Y_BOUTON_NAVIG_LIGNE_2, LARGEUR_BOUTON_NAVIG, HAUTEUR_BOUTON_NAVIG, code);
			b->s1 = load_image("RESSOURCES/NAVIG/5-2.bmp");
			b->s2 = load_image("RESSOURCES/NAVIG/5-2_click.bmp");
			break;
	}
	b->sprite = b->s1;
}

void init_data_navig(navig_t* n){
	n->ouvert = true;
	n->fond =  load_image("RESSOURCES/FONDNIVEAU.bmp");
	n->lequel = 0;
	n->nb_bouton = NB_BOUTON_MAX_NAVIG;
	for(int i = 0; i<n->nb_bouton; i++){
		init_data_bouton_navig(&n->tab_bouton[i],i+1);
	}
	init_souris(&n->souris);
}
