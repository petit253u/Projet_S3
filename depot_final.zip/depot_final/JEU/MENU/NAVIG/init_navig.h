/**
* \file init_fuir.h
* \brief Module d'inititialisation
* \author 
* \version 0.1
* \date 
*/

#ifndef INIT_NAVIG_H
#define INIT_NAVIG_H

#include "../../JEU_GENERAL/GENERAL/sdl-light.h"

void init_data_bouton_navig(bouton_t* b, int code);

void init_data_navig(navig_t* n);

#endif
