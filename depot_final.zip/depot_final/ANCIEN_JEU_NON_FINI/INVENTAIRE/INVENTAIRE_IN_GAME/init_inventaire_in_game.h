/**
* \file init_fuir.h
* \brief Module d'inititialisation
* \author 
* \version 0.1
* \date 
*/

#ifndef INIT_INVENTAIRE_IN_GAME_H
#define INIT_INVENTAIRE_IN_GAME_H

#include "../../GENERAL/sdl-light.h"

void init_inv_in_game_bouton_navig_1(bouton_inv_in_game_t* b, int i);

/////////////////////////////////////////

void init_inv_in_game_bouton_navig_2(bouton_inv_in_game_t* b, int i);

////////////////////////////////////////////////////////////////////////////////////////////////////////

void init_inventaire_in_game(inventaire_in_game_t* inv);

#endif
