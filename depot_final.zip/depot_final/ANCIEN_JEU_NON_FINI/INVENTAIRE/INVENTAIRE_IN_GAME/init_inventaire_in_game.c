#include "../../GENERAL/general.h"


void init_inv_in_game_bouton_navig_1(bouton_inv_in_game_t* b, int i){
	b->hauteur = HAUTEUR_BOUTON_1_NAVIG_INV;
	b->largeur = LARGEUR_BOUTON_1_NAVIG_INV;
	b->x = 30;
	b->y = 30 + (b->hauteur * i);
	b->s1 = ;
	b->s2 = ;
	b->sprite = b->s1;
}

/////////////////////////////////////////

void init_inv_in_game_bouton_navig_2(bouton_inv_in_game_t* b, int i){
	b->hauteur = HAUTEUR_BOUTON_2_NAVIG_INV;
	b->largeur = LARGEUR_BOUTON_2_NAVIG_INV;
	b->x = 430;
	b->y = 30 + (b->hauteur * i);
	b->s1 = ;
	b->s2 = ;
	b->sprite = b->s1;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////

void init_inventaire_in_game(inventaire_in_game_t* inv){
	inv->ouvert = true;
	inv->x = 25;
	inv->y = 25;
	inv->fond = ;
	inv->nbbouton = NB_BOUTON_MAX_INV_IN_GAME_1;
	for(int i=0; i<inv->nbbouton; i++){
		init_inv_in_game_bouton_navig_1(&inv->tabbouton[i], i);
	}
	inv->selection = 0;
	inv->fond2 = ;
	inv->nbbouton2 = NB_BOUTON_MAX_INV_IN_GAME_2;
	for(int i=0; i<inv->nbbouton2; i++){
		init_inv_in_game_bouton_navig_2(&inv->tabbouton2[i], i);
	}
	init_souris(&inv->s);
}

