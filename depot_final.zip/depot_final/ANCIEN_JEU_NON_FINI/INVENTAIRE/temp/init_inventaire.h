/**
* \file init_fuir.h
* \brief Module d'inititialisation
* \author 
* \version 0.1
* \date 
*/

#ifndef INIT_INVENTAIRE_H
#define INIT_INVENTAIRE_H

#include "../GENERAL/sdl-light.h"

void init_code_inventaire_zero(int inv);

////////////////

void init_code_inventaire_item(int inv);

///////////////////////////////////////////////////////

void init_cle_inventaire_zero(int inv)

/////////////////////

void reinit_cle_inventaire_zero(inventaire_t* i)

///////////////////////////////////////////////////////

void init_inventaire(inventaire_t* i);

#endif
