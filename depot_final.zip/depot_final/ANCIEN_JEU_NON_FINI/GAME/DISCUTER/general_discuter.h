#include "../../GENERAL/sdl-light.h"
#include <stdbool.h> 

///////////////////////////////////////////////////////

#define LARGEUR_BOUTON_DISCUTER 250

#define HAUTEUR_BOUTON_DISCUTER 100

#define NB_BOUTON_MAX_DISCUTER 4

#define LARGEUR_ECRAN_DISCUTER 850
 
#define HAUTEUR_ECRAN_DISCUTER 400

///////////////////

#define CODE_BOUTON_1_DISCUTER 1

#define CODE_BOUTON_2_DISCUTER 2

#define CODE_BOUTON_3_DISCUTER 3

#define CODE_BOUTON_4_DISCUTER 4

///////////////////

#define X_LIGNE_1_DISCUTER 100

#define X_LIGNE_2_DISCUTER 750

#define Y_LIGNE_1_DISCUTER 75

#define Y_LIGNE_2_DISCUTER 350

///////////////////////////////////////////////////////

struct bouton_discuter_s{
	int x;
	int y;
	int largeur;
	int hauteur;
	SDL_Surface* sprite;
	SDL_Surface* s1;
	SDL_Surface* s2;
	int code; 
};
typedef struct bouton_discuter_s bouton_discuter_t;

struct discuter_s{
	int nb_bouton;
	bouton_discuter_t tabbouton[NB_BOUTON_MAX_DISCUTER];
	SDL_Surface* fond;
	SDL_Surface* arcade;
	souris_t souris;
	bool ouvert; //true : tj ouvert ; false : ferme 
	int code;
};
typedef struct discuter_s discuter_t;
