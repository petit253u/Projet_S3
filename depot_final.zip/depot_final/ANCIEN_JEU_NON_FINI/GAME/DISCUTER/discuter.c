#include "../../GENERAL/general.h"

void resultat_discuter(combat_t* combat){
	switch(combat->discuter.code){
		case CODE_BOUTON_1_DISCUTER :

			break;
		case CODE_BOUTON_2_DISCUTER :

			break;
		case CODE_BOUTON_3_DISCUTER :

			break;
		case CODE_BOUTON_4_DISCUTER :

			break;
	}
}

/////////////////////////////////////////////////////////////////////////////////////

void verif_pos_souris_discuter(bouton_discuter_t* b, souris_t* s){
	if((s->x >= b->x)&&(s->x <= b->x + b->largeur)){
		if((s->y >= b->y)&&(s->y <= b->y + b->hauteur)){
			b->sprite = b->s2;
			return;
		}
	}
	b->sprite = b->s1;
}

void verif_click_souris_discuter(discuter_t* d, bouton_discuter_t* b, souris_t* s){
	if((s->click_x >= b->x)&&(s->click_x <= b->x + b->largeur)){
		if((s->click_y >= b->y)&&(s->click_y <= b->y + b->hauteur)){
			d->code = b->code;
			d->ouvert = false;
			return;
		}
	}
}

void verif_souris_discuter(discuter_t* discuter){
	for(int i=0; i<discuter->nb_bouton; i++){
		verif_pos_souris_discuter(&discuter->tabbouton[i], &discuter->souris);
		verif_click_souris_discuter(discuter, &discuter->tabbouton[i], &discuter->souris);
	}
}

/////////////////////////////////////////////////////////////////////////////////////

void update_click_souris_discuter(souris_t* souris, int x, int y){
	souris->click_x = x;
	souris->click_y = y;
}

void update_pos_souris_discuter(souris_t* souris, int x, int y){
	souris->x = x;
	souris->y = y;	
}

/////////////////////////////////////////////////////////////////////////////////////

void init_graphics_discuter_bouton(bouton_discuter_t* b, SDL_Surface *ecran){
	printf("INIT BOUTON TADADADAAAA\n");
	//set_transparence(ecran, b->s1, 255, 0, 255);
	printf("INIT BOUTON HFSNFLKSB\n");
	//set_transparence(ecran, b->s2, 255, 0, 255);
}

void init_graphics_discuter(SDL_Surface *ecran, discuter_t* discuter){
	for(int i=0; i<4; i++){
		init_graphics_discuter_bouton(&discuter->tabbouton[i],ecran);
	}
	//set_transparence(ecran, discuter->arcade, 255, 0, 255);
}

/////////////////////////////////////////////////////////////////////////////////////

void refresh_graphics_bouton_discuter(bouton_discuter_t* b,SDL_Surface *ecran){
	apply_surface(b->sprite,ecran,b->x,b->y);
}

void refresh_graphics_discuter(discuter_t* d, SDL_Surface *ecran){
	apply_surface(d->fond,ecran,75,75); 
	for(int i=0; i<4; i++){
		refresh_graphics_bouton_discuter(&d->tabbouton[i],ecran);
	}
	apply_surface(d->arcade,ecran,25,25);
	refresh_surface(ecran);
}

/////////////////////////////////////////////////////////////////////////////////////

void handle_event_discuter(SDL_Event *event, world_t *world){
	int mouseX, mouseY;
	while( SDL_PollEvent( event ) ) {
		//Si l'utilisateur a cliqué sur le X de la fenêtre
		if( event->type == SDL_QUIT ) {
			//On quitte le programme
			world->combat.gameover = 1;
			world->combat.victoire = false;
			world->combat.ouvert = false;
			world->gameover = 1;
		}
		/* Si l'utilisateur appuie sur
		la touche droite de la souris */
		if( event->type == SDL_MOUSEBUTTONDOWN){
              		SDL_GetMouseState(&mouseX, &mouseY);
			update_click_souris_discuter(&world->combat.discuter.souris, mouseX, mouseY);
		}
		if( event->type == SDL_MOUSEMOTION){
			//printf("BOUGE\n");
			SDL_GetMouseState(&mouseX, &mouseY);
			update_pos_souris_discuter(&world->combat.discuter.souris, mouseX, mouseY);
		}
	}
} 

/////////////////////////////////////////////////////////////////////////////////////

void boucle_discuter(world_t* world,SDL_Surface *ecran){
	SDL_Event event_discuter;
	printf("INIT fuir\n");
	init_discuter(&world->combat.discuter);
	printf("INIT GRAPHICS \n");
	init_graphics_discuter(ecran,&world->combat.discuter);
	printf("CONDITION BOUCLE\n");
	while(world->combat.discuter.ouvert == true){
		printf("123\n");
		handle_event_discuter(&event_discuter,world);
		printf("123\n");
		verif_souris_discuter(&world->combat.discuter);
		printf("123\n");
		refresh_graphics_discuter(&world->combat.discuter,ecran);
	}
	resultat_discuter(&world->combat);
	SDL_Delay(350);
}
