#ifndef DISCUTER_H
#define DISCUTER_H

#include "../../GENERAL/sdl-light.h"

void resultat_discuter(combat_t* combat);

/////////////////////////////////////////////////////////////////////////////////////

void verif_pos_souris_discuter(bouton_discuter_t* b, souris_t* s);

void verif_click_souris_discuter(discuter_t* d, bouton_discuter_t* b, souris_t* s);

void verif_souris_discuter(discuter_t* discuter);

/////////////////////////////////////////////////////////////////////////////////////

void update_click_souris_discuter(souris_t* souris, int x, int y);

void update_pos_souris_discuter(souris_t* souris, int x, int y);

/////////////////////////////////////////////////////////////////////////////////////

void init_graphics_discuter_bouton(bouton_discuter_t* b, SDL_Surface *ecran);

void init_graphics_discuter(SDL_Surface *ecran, discuter_t* discuter);

/////////////////////////////////////////////////////////////////////////////////////

void refresh_graphics_bouton_discuter(bouton_discuter_t* c,SDL_Surface *ecran);

void refresh_graphics_discuter(discuter_t* d, SDL_Surface *ecran);

/////////////////////////////////////////////////////////////////////////////////////

void handle_event_discuter(SDL_Event *event, world_t *world);

/////////////////////////////////////////////////////////////////////////////////////

void boucle_discuter(world_t* world,SDL_Surface *ecran);

#endif
