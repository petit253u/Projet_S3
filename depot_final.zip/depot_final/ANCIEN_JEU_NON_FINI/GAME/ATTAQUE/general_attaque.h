/**
* \file general_devine_couleur.h
* \brief Module de structure et constante
* \author 
* \version 0.1
* \date 
*/

#include "../../GENERAL/sdl-light.h"
#include <stdbool.h> 

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

#define CENTRE_CIBLE_ATTAQUE_X 400

#define CENTRE_CIBLE_ATTAQUE_Y 200

#define MOVING_VISEUR_ATTAQUE 1

#define MOVING_BORNE_ATTAQUE 1 

#define TAILLE_COTE_VISEUR 20

#define LARGEUR_CACHE_BORNE_ATTAQUE 80

#define HAUTEUR_CACHE_BORNE_ATTAQUE 400

#define X_CACHE_BORNE_ATTAQUE 800

#define Y_CACHE_BORNE_ATTAQUE 100

#define DISTANCE_VISEUR_BORD_DROIT 450

#define DISTANCE_VISEUR_BORD_GAUCHE 200

#define DISTANCE_BORNE_BORD_HAUT 120

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

struct viseur_s{
	int x;
	int y;
	int centre_x;
	int centre_y;
	int distance; // distance par rapport au centre de la cible 
	int tour; // 1 : vers la droite ; 2 : vers la gauche 
	bool bouge; //true : bouge; false : ne bouge pas 
	SDL_Surface* sprite;
};
typedef struct viseur_s viseur_t;
	
struct borne_s{
	int x_cache;
	int y_cache;
	int largeur_cache;
	int hauteur_cache;
	int tour; // 1 : vers le haut ; 2 : vers le bas
	bool bouge; //true : bouge; false : ne bouge pas 
	SDL_Surface* cache_borne;
	SDL_Surface* borne_couleur;
	int distance ; // distance par rapport à la puissance de la borne (peu intuitif) 
};
typedef struct borne_s borne_t;

struct attaque_s{
	borne_t borne;
	viseur_t viseur;
	SDL_Surface* fond;
	SDL_Surface* arcade;
	bool ouvert; //true : tj ouvert ; false : ferme  
};
typedef struct attaque_s attaque_t;
