/**
* \file init_fuir.h
* \brief Module d'inititialisation
* \author 
* \version 0.1
* \date 
*/

#ifndef INIT_NIVEAU_2_H
#define INIT_NIVEAU_2_H

#include "../../GENERAL/sdl-light.h"

void init_salle_i_niv_2(int i, salle_t* salle);

void init_niveau_2(niveau_t* n);

#endif
