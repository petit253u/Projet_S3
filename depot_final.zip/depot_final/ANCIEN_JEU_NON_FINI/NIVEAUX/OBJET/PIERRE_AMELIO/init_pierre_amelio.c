#include "../../../GENERAL/general.h"

void init_data_pierre_amelio(pierre_amelio_t* p, int x, int y){
	p->x = x;
	p->y = y;
	p->largeur = LARGEUR_PIERRE_AMELIO;
	p->hauteur = HAUTEUR_PIERRE_AMELIO;
	p->s1 = ;
	p->s2 = ;
	p->sprite = p->s1;
}
