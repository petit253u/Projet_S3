#include "../../../GENERAL/general.h"

void init_lire_code_porte(porte_t* p){
	switch(p->code){
		case TYPE_PORTE_BELIER:
			p->s1 = ;
			p->s2 = ;
			p->sprite = p->s1;
			break;
		case TYPE_PORTE_TAUREAU:
			p->s1 = ;
			p->s2 = ;
			p->sprite = p->s1;		
			break;
		case TYPE_PORTE_GEMEAUX:
			p->s1 = ;
			p->s2 = ;
			p->sprite = p->s1;		
			break;
		case TYPE_PORTE_CANCER:
			p->s1 = ;
			p->s2 = ;
			p->sprite = p->s1;		
			break;
		case TYPE_PORTE_LION:
			p->s1 = ;
			p->s2 = ;
			p->sprite = p->s1;		
			break;
		case TYPE_PORTE_VIERGE:
			p->s1 = ;
			p->s2 = ;
			p->sprite = p->s1;		
			break;
		case TYPE_PORTE_BALANCE:
			p->s1 = ;
			p->s2 = ;
			p->sprite = p->s1;		
			break;
		case TYPE_PORTE_SCORPION:
			p->s1 = ;
			p->s2 = ;
			p->sprite = p->s1;		
			break;
		case TYPE_PORTE_SAGITTAIRE:
			p->s1 = ;
			p->s2 = ;
			p->sprite = p->s1;		
			break;
		case TYPE_PORTE_CAPRICORNE:
			p->s1 = ;
			p->s2 = ;
			p->sprite = p->s1;		
			break;
		case TYPE_PORTE_VERSEAU:
			p->s1 = ;
			p->s2 = ;
			p->sprite = p->s1;		
			break;
		case TYPE_PORTE_POISSON:
			p->s1 = ;
			p->s2 = ;
			p->sprite = p->s1;		
			break;
		default:
			printf("PROBLEME CODE PORTE\n");
			break;
	}
}

void init_data_porte(porte_t* p, int x, int y, int CODE){
	p->x = x;
	p->y = y;
	p->largeur = LARGEUR_PORTE;
	p->hauteur = HAUTEUR_PORTE;
	p->code = CODE;
	init_lire_code_porte(p);
}
