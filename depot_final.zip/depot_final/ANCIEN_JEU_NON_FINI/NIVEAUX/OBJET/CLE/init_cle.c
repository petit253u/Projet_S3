#include "../../../GENERAL/general.h"

void init_lire_code_cle(cle_t* c){
	switch(c->code){
		case TYPE_CLE_BELIER:
			c->s1 = ;
			c->s2 = ;
			c->sprite = c->s1;
			break;
		case TYPE_CLE_TAUREAU:
			c->s1 = ;
			c->s2 = ;
			c->sprite = c->s1;		
			break;
		case TYPE_CLE_GEMEAUX:
			c->s1 = ;
			c->s2 = ;
			c->sprite = c->s1;		
			break;
		case TYPE_CLE_CANCER:
			c->s1 = ;
			c->s2 = ;
			c->sprite = c->s1;		
			break;
		case TYPE_CLE_LION:
			c->s1 = ;
			c->s2 = ;
			c->sprite = c->s1;		
			break;
		case TYPE_CLE_VIERGE:
			c->s1 = ;
			c->s2 = ;
			c->sprite = c->s1;		
			break;
		case TYPE_CLE_BALANCE:
			c->s1 = ;
			c->s2 = ;
			c->sprite = c->s1;		
			break;
		case TYPE_CLE_SCORPION:
			c->s1 = ;
			c->s2 = ;
			c->sprite = c->s1;		
			break;
		case TYPE_CLE_SAGITTAIRE:
			c->s1 = ;
			c->s2 = ;
			c->sprite = c->s1;		
			break;
		case TYPE_CLE_CAPRICORNE:
			c->s1 = ;
			c->s2 = ;
			c->sprite = c->s1;		
			break;
		case TYPE_CLE_VERSEAU:
			c->s1 = ;
			c->s2 = ;
			c->sprite = c->s1;		
			break;
		case TYPE_CLE_POISSON:
			c->s1 = ;
			c->s2 = ;
			c->sprite = c->s1;		
			break;
		default:
			printf("PROBLEME CODE CLE\n");
			break;
	}
}

void init_data_cle(cle_t* c, int x, int y, int CODE){
	c->x = x;
	c->y = y;
	c->largeur = LARGEUR_CLE;
	c->hauteur = HAUTEUR_CLE;
	c->code = CODE;
	init_lire_code_cle(c);
}


