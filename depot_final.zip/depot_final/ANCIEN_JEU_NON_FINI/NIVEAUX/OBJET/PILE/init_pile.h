#ifndef INIT_PILE_H
#define INIT_PILE_H

#include "../../../GENERAL/sdl-light.h"

void init_data_pile(pile_t* p, int x, int y);

#endif
