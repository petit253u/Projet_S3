#include "../../../GENERAL/general.h"

void init_data_coffre_autre(coffre_t* c, int x, int y, int CODE, int nb_contenu){
	c->c1 = ;
	c->c2 = ;
	c->c3 = ;
	c->c4 = ;
	c->sprite = c->c1;
	c->x = x;
	c->y = y;
	c->largeur = LARGEUR_COFFRE;
	c->hauteur = HAUTEUR_COFFRE;
	c->etat = 1;
	c->CODE_CONTENU = CODE;
	c->nb_contenu = nb_contenu;
	switch(CODE){
		 case CODE_COFFRE_CONTIENT_ARGENT:
			c->contenu = ;
			break;		
		 case CODE_COFFRE_CONTIENT_BONBON:
			c->contenu = ;		
			break;	
		 case CODE_COFFRE_CONTIENT_FIOLE:
			c->contenu = ;		
			break;	
		 case CODE_COFFRE_CONTIENT_FROMAGE:
			c->contenu = ;		
			break;	
		 case CODE_COFFRE_CONTIENT_PIERRE:
			c->contenu = ;		
			break;	
		 case CODE_COFFRE_CONTIENT_PILE:
			c->contenu = ;		
			break;	
		 case CODE_COFFRE_CONTIENT_SNACK:
			c->contenu = ;		
			break;	
	}
	
}

void init_data_coffre_lettre(coffre_t* c, int x, int y, int CODE, int CODE_LETTRE){
	c->c1 = ;
	c->c2 = ;
	c->c3 = ;
	c->c4 = ;
	c->sprite = c->c1;
	c->x = x;
	c->y = y;
	c->largeur = LARGEUR_COFFRE;
	c->hauteur = HAUTEUR_COFFRE;
	c->etat = 1;
	c->CODE_CONTENU = CODE;
	c->nb_contenu = 1;
	c->CODE_OBJET = CODE_O;
	switch(CODE_LETTRE){
		case LETTRE_CONTENU_1:
			c->contenu = ;
			break;	
		case LETTRE_CONTENU_2:
			c->contenu = ;
			break;
		case LETTRE_CONTENU_3:
			c->contenu = ;
			break;
		case LETTRE_CONTENU_4:
			c->contenu = ;
			break;
		case LETTRE_CONTENU_5:
			c->contenu = ;
			break;
		case LETTRE_CONTENU_6:
			c->contenu = ;
			break;	
		case LETTRE_CONTENU_7:
			c->contenu = ;
			break;
		case LETTRE_CONTENU_8:
			c->contenu = ;
			break;
		case LETTRE_CONTENU_9:
			c->contenu = ;
			break;
		case LETTRE_CONTENU_10:
			c->contenu = ;
			break;
		case LETTRE_CONTENU_11:
			c->contenu = ;
			break;	
		case LETTRE_CONTENU_12:
			c->contenu = ;
			break;
		case LETTRE_CONTENU_13:
			c->contenu = ;
			break;
		case LETTRE_CONTENU_14:
			c->contenu = ;
			break;
		case LETTRE_CONTENU_15:
			c->contenu = ;
			break;
		case LETTRE_CONTENU_16:
			c->contenu = ;
			break;	
		case LETTRE_CONTENU_17:
			c->contenu = ;
			break;
		case LETTRE_CONTENU_18:
			c->contenu = ;
			break;
		case LETTRE_CONTENU_19:
			c->contenu = ;
			break;
		case LETTRE_CONTENU_20:
			c->contenu = ;
			break;
	}
}

void init_data_coffre_cle(coffre_t* c, int x, int y, int CODE, int CODE_CLE){
	c->c1 = ;
	c->c2 = ;
	c->c3 = ;
	c->c4 = ;
	c->sprite = c->c1;
	c->x = x;
	c->y = y;
	c->largeur = LARGEUR_COFFRE;
	c->hauteur = HAUTEUR_COFFRE;
	c->etat = 1;
	c->CODE_CONTENU = CODE;
	c->nb_contenu = 1;
	c->CODE_OBJET = CODE_CLE;
	switch(CODE_CLE){
		case TYPE_CLE_BELIER:
			c->contenu = ;
			break;	
		case TYPE_CLE_TAUREAU:
			c->contenu = ;
			break;	
		case TYPE_CLE_GEMEAUX:
			c->contenu = ;
			break;	
		case TYPE_CLE_CANCER:
			c->contenu = ;
			break;	
		case TYPE_CLE_LION:
			c->contenu = ;
			break;	
		case TYPE_CLE_VIERGE:
			c->contenu = ;
			break;	
		case TYPE_CLE_BALANCE:
			c->contenu = ;
			break;	
		case TYPE_CLE_SCORPION:
			c->contenu = ;
			break;	
		case TYPE_CLE_SAGITTAIRE:
			c->contenu = ;
			break;	
		case TYPE_CLE_CAPRICORNE:
			c->contenu = ;
			break;	
		case TYPE_CLE_VERSEAU:
			c->contenu = ;
			break;	
		case TYPE_CLE_POISSON:
			c->contenu = ;
			break;		
	}
}

void init_data_coffre_ouvert(coffre_t* c, int x, int y, int etat){
	c->c1 = ;
	c->c2 = ;
	c->c3 = ;
	c->c4 = ;
	c->x = x;
	c->y = y;
	c->largeur = LARGEUR_COFFRE;
	c->hauteur = HAUTEUR_COFFRE;
	c->etat = etat;
	switch(etat){
		case 2:
			c->sprite = c->c3;
			break;		
		case 3:
			c->sprite = c->c4;
			break;	
	}
	c->sprite = c->c1;
}
