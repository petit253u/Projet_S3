#include "../../../GENERAL/sdl-light.h"
#include <stdbool.h> 

///////////////////////////////////////////////////////

#define LARGEUR_COFFRE 200
#define HAUTEUR_COFFRE 200

////////////////////////

#define CODE_COFFRE_CONTIENT_ARGENT 1
#define CODE_COFFRE_CONTIENT_BONBON 2
#define CODE_COFFRE_CONTIENT_CLE 3
#define CODE_COFFRE_CONTIENT_FIOLE 4 
#define CODE_COFFRE_CONTIENT_FROMAGE 5
#define CODE_COFFRE_CONTIENT_LETTRE 6
#define CODE_COFFRE_CONTIENT_PIERRE 7 
#define CODE_COFFRE_CONTIENT_PILE 8
#define CODE_COFFRE_CONTIENT_SNACK 9

////////////////////////

#define NB_COFFRE_NIV_1_SALLE_1 
#define NB_COFFRE_NIV_1_SALLE_2 
#define NB_COFFRE_NIV_1_SALLE_3 
#define NB_COFFRE_NIV_1_SALLE_4 
#define NB_COFFRE_NIV_1_SALLE_5 
#define NB_COFFRE_NIV_1_SALLE_6
#define NB_COFFRE_NIV_1_SALLE_7
#define NB_COFFRE_NIV_1_SALLE_8

////////////////////////

#define NB_COFFRE_NIV_2_SALLE_1 
#define NB_COFFRE_NIV_2_SALLE_2 
#define NB_COFFRE_NIV_2_SALLE_3 
#define NB_COFFRE_NIV_2_SALLE_4 
#define NB_COFFRE_NIV_2_SALLE_5 
#define NB_COFFRE_NIV_2_SALLE_6
#define NB_COFFRE_NIV_2_SALLE_7
#define NB_COFFRE_NIV_2_SALLE_8

////////////////////////

#define NB_COFFRE_NIV_3_SALLE_1 
#define NB_COFFRE_NIV_3_SALLE_2 
#define NB_COFFRE_NIV_3_SALLE_3 
#define NB_COFFRE_NIV_3_SALLE_4 
#define NB_COFFRE_NIV_3_SALLE_5 
#define NB_COFFRE_NIV_3_SALLE_6
#define NB_COFFRE_NIV_3_SALLE_7
#define NB_COFFRE_NIV_3_SALLE_8

///////////////////////////////////////////////////////

struct coffre_s{
	int x; 
	int y;
	int largeur;
	int hauteur;
	int etat; // 1:fermé, 2:reussi; 3:echec
	SDL_Surface* c1; // Fermé
	SDL_Surface* c2; // Cliquable
	SDL_Surface* c3; // Reussi
	SDL_Surface* c4; // Echec
	SDL_Surface* sprite;
	devine_couleur_t dc;
	int CODE_CONTENU;
	int CODE_OBJET;
	int nb_contenu;
	SDL_Surface* contenu;	
};
typedef struct coffre_s coffre_t;

