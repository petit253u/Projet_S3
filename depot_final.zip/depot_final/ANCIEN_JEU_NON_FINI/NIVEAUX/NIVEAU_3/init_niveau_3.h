/**
* \file init_fuir.h
* \brief Module d'inititialisation
* \author 
* \version 0.1
* \date 
*/

#ifndef INIT_NIVEAU_3_H
#define INIT_NIVEAU_3_H

#include "../../GENERAL/sdl-light.h"

void init_salle_i_niv_3(int i, salle_t* salle);

void init_niveau_3(niveau_t* n);

#endif
