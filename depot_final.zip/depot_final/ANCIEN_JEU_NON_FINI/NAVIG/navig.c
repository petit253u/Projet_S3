#include "../GENERAL/general.h"


void update_click_souris_navig(souris_t *souris, int x, int y){
	souris->click_x = x;
	souris->click_y = y;
}

void update_pos_souris_navig(souris_t *souris, int x, int y){
	souris->x = x;
	souris->y = y;	
}

////////////////////////

void handle_event_navig(SDL_Event *event, world_t *world){
	int mouseX, mouseY;
	while( SDL_PollEvent( event ) ) {
		//Si l'utilisateur a cliqué sur le X de la fenêtre
		if( event->type == SDL_QUIT ) {
			//On quitte le programme
			world->gameover = 1;
			world->navig.ouvert = false;
		}
		/* Si l'utilisateur appuie sur
		la touche droite de la souris */
		if( event->type == SDL_MOUSEBUTTONDOWN){
              		SDL_GetMouseState(&mouseX, &mouseY);
			update_click_souris_navig(&world->navig.souris, mouseX, mouseY);
		}
		if( event->type == SDL_MOUSEMOTION){
			//printf("BOUGE\n");
			SDL_GetMouseState(&mouseX, &mouseY);
			update_pos_souris_navig(&world->navig.souris, mouseX, mouseY);
		}
	}
} 

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void init_graphics_bouton_navig(SDL_Surface *ecran, bouton_navig_t* b){
	set_transparence(ecran, b->b1, 255, 0, 255);
	set_transparence(ecran, b->b2, 255, 0, 255);
}

void init_graphics_navig(SDL_Surface *ecran, navig_t *n){
	set_transparence(ecran, n->jaquette, 255, 0, 255);
	set_transparence(ecran, n->inv_fond, 255, 0, 255);
	set_transparence(ecran, n->viseur, 255, 0, 255);
	for(int i=0; i<n->nb_bouton; i++){
		init_graphics_bouton_navig(ecran,&n->tabbouton[i]);
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void refresh_graphics_viseur_navig(SDL_Surface *ecran, navig_t *navig){
	switch(navig->lequel){
		case LEQUEL_BOUTON_NAVIG_NIV_1:
			apply_surface(navig->viseur,ecran, X_VISEUR_NAVIG_NIV_1,Y_VISEUR_NAVIG_NIV_1);
			break;
		case LEQUEL_BOUTON_NAVIG_NIV_2:
			apply_surface(navig->viseur,ecran, X_VISEUR_NAVIG_NIV_2,Y_VISEUR_NAVIG_NIV_2);
			break;
		case LEQUEL_BOUTON_NAVIG_NIV_3:
			apply_surface(navig->viseur,ecran, X_VISEUR_NAVIG_NIV_3,Y_VISEUR_NAVIG_NIV_3);
			break;
	}
}

void refresh_graphics_bouton_navig(SDL_Surface *ecran, bouton_navig_t* b){
	apply_surface(b->sprite,ecran, b->x,b->y);
}

void refresh_graphics_navig(SDL_Surface *ecran, navig_t *navig){
	apply_surface(navig->fond,ecran, 0,0);
	apply_surface(navig->jaquette,ecran, 0,0);
	apply_surface(navig->inv_fond,ecran, X_BOUTON_NAVIG_LIGNE_2,Y_BOUTON_NAVIG_LIGNE_1);
	refresh_graphics_viseur_navig(ecran,navig);
	for(int i=0; i<navig->nb_bouton; i++){
		if(navig->tabbouton[i].la == true){
			refresh_graphics_bouton_navig(ecran,&navig->tabbouton[i]);
		}
	}
	refresh_surface(ecran);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void lire_lequel_navig(world_t *world,SDL_Surface *ecran){
	switch(world->navig.lequel){
		case LEQUEL_BOUTON_NAVIG_NIV_1:
			//Lance niv 1
			world->navig.ouvert = false; // POUR L'INSTANT ( A ENLEVER POUR METTRE LES BOUCLES NIVEAUX)
			break;
		case LEQUEL_BOUTON_NAVIG_NIV_2:
			//Lance niv 2
			world->navig.ouvert = false; // POUR L'INSTANT ( A ENLEVER POUR METTRE LES BOUCLES NIVEAUX)
			break;
		case LEQUEL_BOUTON_NAVIG_NIV_3:
			//Lance niv 3
			world->navig.ouvert = false; // POUR L'INSTANT ( A ENLEVER POUR METTRE LES BOUCLES NIVEAUX)
			break;
	}
}

void lire_bouton_navig(world_t *world,SDL_Surface *ecran,int i){
	switch(i){
		case LEQUEL_BOUTON_NAVIG_SAUV:
			//boucle suavegarde;
			world->navig.lequel = 0;
			break;
		case LEQUEL_BOUTON_NAVIG_NIV_1:
			world->navig.lequel = LEQUEL_BOUTON_NAVIG_NIV_1;
			break;
		case LEQUEL_BOUTON_NAVIG_NIV_2:
			world->navig.lequel = LEQUEL_BOUTON_NAVIG_NIV_2;
			break;
		case LEQUEL_BOUTON_NAVIG_NIV_3:
			world->navig.lequel = LEQUEL_BOUTON_NAVIG_NIV_3;
			break;
		case LEQUEL_BOUTON_NAVIG_ACHAT:
			boucle_distributeur(world,ecran);
			world->navig.lequel = 0;
			break;
		case LEQUEL_BOUTON_NAVIG_GO:
			lire_lequel_navig(world,ecran);
			world->navig.lequel = 0;
			break;
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void verif_click_navig(bouton_navig_t* b,souris_t* s,world_t *world,SDL_Surface *ecran,int i){
	if((s->click_x >= b->x) && (s->click_x <= b->x + b->largeur)){
		if((s->click_y >= b->y) && (s->click_y <= b->y + b->hauteur)){
			lire_bouton_navig(world,ecran,i);
			s->click_x = -100;
			s->click_y = -100;
		}
	}
}

/////////////////////////

void verif_pos_navig(bouton_navig_t* b,souris_t* s){
	if((s->x >= b->x) && (s->x <= b->x + b->largeur)){
		if((s->y >= b->y) && (s->y <= b->y + b->hauteur)){
			b->sprite = b->b2;
			return;
		}
	}
	b->sprite = b->b1;
}

/////////////////////////

void verif_navig(world_t *world,SDL_Surface *ecran){
	for(int i=0; i<world->navig.nb_bouton; i++){
		if(world->navig.tabbouton[i].la == true){
			verif_pos_navig(&world->navig.tabbouton[i],&world->navig.souris);
			verif_click_navig(&world->navig.tabbouton[i],&world->navig.souris,world,ecran,i);
		}
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

int boucle_navig(world_t *world,SDL_Surface *ecran){
	SDL_Event event_navig;
	init_data_navig(&world->navig);
	init_graphics_navig(ecran,&world->navig);
	SDL_EnableKeyRepeat(100,100);	
	while(world->navig.ouvert == true){
		handle_event_navig(&event_navig, world);
		verif_navig(world,ecran);
		refresh_graphics_navig(ecran,&world->navig);
	}
}
