/**
* \file general_joueur.h
* \brief Module de structure et constante
* \author 
* \version 0.1
* \date 
*/

#include "../GENERAL/sdl-light.h"
#include <stdbool.h> 

///////////////////////////////////////////////////////

#define PV_MAX_RATABULBE 100

#define DIF_FUIR_RATAFLEUR 6

#define X_RATAFLEUR 400

#define Y_RATAFLEUR 300

///////////////////////////////////////////////////////


