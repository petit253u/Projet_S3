/**
* \file init_joueur.h
* \brief Module d'inititialisation
* \author 
* \version 0.1
* \date 
*/

#ifndef INIT_RATARACINE_H
#define INIT_RATARACINE_H

#include "../GENERAL/sdl-light.h"

void init_paterne_cube_rataracine_1(paterne_cube_t* p);

void init_paterne_cube_rataracine_2(paterne_cube_t* p);

void init_paterne_cube_rataracine_3(paterne_cube_t* p);

void init_paterne_cube_rataracine_4(paterne_cube_t* p);

void init_paterne_cube_rataracine_i(paterne_cube_t* p,int paterne);

void init_paterne_cube_rataracine(ennemi_t* e);

void init_data_ennemi_rataracine(ennemi_t* e);

#endif
