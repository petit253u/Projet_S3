/**
* \file general_joueur.h
* \brief Module de structure et constante
* \author 
* \version 0.1
* \date 
*/

#include "../GENERAL/sdl-light.h"
#include <stdbool.h> 

///////////////////////////////////////////////////////

#define PV_MAX_RATARACINE 100

#define DIF_FUIR_RATARACINE 6

#define X_RATARACINE 400

#define Y_RATARACINE 300

///////////////////////////////////////////////////////

