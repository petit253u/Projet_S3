/**
* \file init_joueur.h
* \brief Module d'inititialisation
* \author 
* \version 0.1
* \date 
*/

#ifndef INIT_JOUEUR_H
#define INIT_JOUEUR_H

#include "../GENERAL/sdl-light.h"

void init_data_joueur(joueur_t* j);

#endif
