#include "../GENERAL/general.h"

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void refresh_graphics_rouleau_distributeur(SDL_Surface *ecran,rouleau_t* r){
	if(r->a_faire_tomber == 0){
		apply_surface(r->item_3,ecran, r->x+25,r->y-25);
		apply_surface(r->item_2,ecran, r->x-15,r->y+10);
		apply_surface(r->item_1,ecran, r->x,r->y);
		apply_surface(r->anneau,ecran, r->x,r->y);
	}
}

void refresh_graphics_bouton_distributeur(SDL_Surface *ecran,bouton_dist_t* b){
	apply_surface(b->sprite,ecran, b->x,b->y);
}

void refresh_graphics_dis(SDL_Surface *ecran, distributeur_t* d){
	apply_surface(d->fond,ecran, 0,0);
	for(int i = 0; i<d->nbrouleau; i++){
		refresh_graphics_rouleau_distributeur(ecran,&d->tabrouleau[i]);
	}
	apply_surface(d->devant,ecran, 0,0);
	apply_surface(d->achat,ecran,X_ECRAN_ACHAT,Y_ECRAN_ACHAT);
	for(int i = 0; i<d->nbbouton; i++){
		refresh_graphics_bouton_distributeur(ecran,&d->tabbouton[i]);
	}
	refresh_surface(ecran);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////

void refresh_affichage_particulier_rouleau(SDL_Surface *ecran,rouleau_t* r, int yitem, int xrouleau, int yrouleau){
	if(r->a_faire_tomber == 1){
		apply_surface(r->item_3,ecran, r->x+25,r->y-25);
		apply_surface(r->item_2,ecran, r->x-15,r->y+10);
		apply_surface(r->item_1,ecran, r->x,yitem);
		apply_surface(r->anneau,ecran, xrouleau,yrouleau);
	}
}

void refresh_affichage_particulier(SDL_Surface *ecran, distributeur_t* d, int yitem, int xrouleau, int yrouleau){	
	apply_surface(d->fond,ecran, 0,0);
	for(int i = 0; i<d->nbrouleau; i++){
		refresh_graphics_rouleau_distributeur(ecran,&d->tabrouleau[i]);
		refresh_affichage_particulier_rouleau(ecran,&d->tabrouleau[i], yitem, xrouleau, yrouleau);
	}
	apply_surface(d->devant,ecran, 0,0);
	apply_surface(d->achat,ecran,X_ECRAN_ACHAT,Y_ECRAN_ACHAT);
	for(int i = 0; i<d->nbbouton; i++){
		 refresh_graphics_bouton_distributeur(ecran,&d->tabbouton[i]);
	}
	refresh_surface(ecran);
}

////////////////////////

void affichage_fiole_tombe(world_t *world, SDL_Surface *ecran){
	world->dis.tabrouleau[1].a_faire_tomber = 1;
	int xrouleau = -1000, yrouleau = -1000;
	for(int i = world->dis.tabrouleau[1].y ; i<world->dis.tabrouleau[1].y + 1200; i=i+10){
		refresh_affichage_particulier(ecran,&world->dis,i,xrouleau,yrouleau);
	}
	refresh_graphics_dis(ecran,&world->dis);
	world->dis.tabrouleau[1].a_faire_tomber = 0;
}

void affichage_snack_tombe(world_t *world, SDL_Surface *ecran){
	world->dis.tabrouleau[0].a_faire_tomber = 1;
	int xrouleau = -1000, yrouleau = -1000;
	for(int i = world->dis.tabrouleau[0].y ; i<world->dis.tabrouleau[1].y + 1200; i=i+10){
		refresh_affichage_particulier(ecran,&world->dis,i,xrouleau,yrouleau);
	}
	refresh_graphics_dis(ecran,&world->dis);
	world->dis.tabrouleau[0].a_faire_tomber = 0;
}

void affichage_bonbon_tombe(world_t *world, SDL_Surface *ecran){
	world->dis.tabrouleau[3].a_faire_tomber = 1;
	int xrouleau = -1000, yrouleau = -1000;
	for(int i = world->dis.tabrouleau[3].y ; i<world->dis.tabrouleau[1].y + 1200; i=i+10){
		refresh_affichage_particulier(ecran,&world->dis,i,xrouleau,yrouleau);
	}
	refresh_graphics_dis(ecran,&world->dis);
	world->dis.tabrouleau[3].a_faire_tomber = 0;
}

void affichage_pile_tombe(world_t *world, SDL_Surface *ecran){
	world->dis.tabrouleau[4].a_faire_tomber = 1;
	int xrouleau = -1000, yrouleau = -1000;
	for(int i = world->dis.tabrouleau[4].y ; i<world->dis.tabrouleau[1].y + 1200; i=i+10){
		refresh_affichage_particulier(ecran,&world->dis,i,xrouleau,yrouleau);
	}
	refresh_graphics_dis(ecran,&world->dis);
	world->dis.tabrouleau[4].a_faire_tomber = 0;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void update_sprite_achat(distributeur_t* d, int lequel){
	switch(lequel){
		case LEQUEL_SIMPLE_DIST:
			d->achat = d->achat_simple;
			break;
		case LEQUEL_FIOLE_DIST:
			d->achat = d->achat_fiole;
			break;
		case LEQUEL_SNACK_DIST:
			d->achat = d->achat_snack;
			break;
		case LEQUEL_BONBON_DIST:
			d->achat = d->achat_bonbon;
			break;
		case LEQUEL_PILE_DIST:
			d->achat = d->achat_pile;
			break;
		case LEQUEL_REFUSER_DIST:
			d->achat = d->achat_refuser;
			break;
		case LEQUEL_ACCEPTER_DIST:
			d->achat = d->achat_accepter;
			break;
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void lecture_achat_fiole(world_t *world, SDL_Surface *ecran){
	if(world->j.argent >= ITEM_SOIN_PRIX){
		world->j.argent = world->j.argent - ITEM_SOIN_PRIX; 
		update_sprite_achat(&world->dis, LEQUEL_ACCEPTER_DIST);
		affichage_fiole_tombe(world,ecran);
		world->dis.selection = 0;
		// mettre dans l'inventaire
		return;
	}
	update_sprite_achat(&world->dis, LEQUEL_REFUSER_DIST);
	SDL_Delay(2000);
	update_sprite_achat(&world->dis, LEQUEL_SIMPLE_DIST);
	world->dis.selection = 0;
}

void lecture_achat_snack(world_t *world, SDL_Surface *ecran){
	if(world->j.argent >= ITEM_ATTAQUE_PRIX){
		world->j.argent = world->j.argent - ITEM_ATTAQUE_PRIX; 
		update_sprite_achat(&world->dis, LEQUEL_ACCEPTER_DIST);
		affichage_snack_tombe(world,ecran);
		world->dis.selection = 0;
		// mettre dans l'inventaire
		return;
	}
	update_sprite_achat(&world->dis, LEQUEL_REFUSER_DIST);
	SDL_Delay(2000);
	update_sprite_achat(&world->dis, LEQUEL_SIMPLE_DIST);
	world->dis.selection = 0;
}

void lecture_achat_bonbon(world_t *world, SDL_Surface *ecran){
	if(world->j.argent >= ITEM_DEFENCE_PRIX){
		world->j.argent = world->j.argent - ITEM_DEFENCE_PRIX; 
		update_sprite_achat(&world->dis, LEQUEL_ACCEPTER_DIST);
		affichage_bonbon_tombe(world,ecran);
		world->dis.selection = 0;
		// mettre dans l'inventaire
		return;
	}
	update_sprite_achat(&world->dis, LEQUEL_REFUSER_DIST);
	SDL_Delay(2000);
	update_sprite_achat(&world->dis, LEQUEL_SIMPLE_DIST);
	world->dis.selection = 0;
}

void lecture_achat_pile(world_t *world, SDL_Surface *ecran){
	if(world->j.argent >= ITEM_PILE_PRIX){
		world->j.argent = world->j.argent - ITEM_PILE_PRIX; 
		update_sprite_achat(&world->dis, LEQUEL_ACCEPTER_DIST);
		affichage_pile_tombe(world,ecran);
		world->dis.selection = 0;
		// mettre dans l'inventaire
		return;
	}
	update_sprite_achat(&world->dis, LEQUEL_REFUSER_DIST);
	SDL_Delay(2000);
	update_sprite_achat(&world->dis, LEQUEL_SIMPLE_DIST);
	world->dis.selection = 0;
}

void verif_achat(world_t *world, SDL_Surface *ecran){
	if(world->dis.selection > 0){
		switch(world->dis.selection){
			case LEQUEL_FIOLE_DIST:
				lecture_achat_fiole(world,ecran);
				break;
			case LEQUEL_SNACK_DIST:
				lecture_achat_snack(world,ecran);
				break;
			case LEQUEL_BONBON_DIST:
				lecture_achat_bonbon(world,ecran);
				break;
			case LEQUEL_PILE_DIST:
				lecture_achat_pile(world,ecran);
				break;
		}
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void lire_bouton(bouton_dist_t* b, world_t *world, SDL_Surface *ecran){
	switch(b->lequel){
		case LEQUEL_FIOLE_DIST:
			update_sprite_achat(&world->dis, LEQUEL_FIOLE_DIST);
			world->dis.selection = LEQUEL_FIOLE_DIST;
			break;
		case LEQUEL_SNACK_DIST:
			update_sprite_achat(&world->dis, LEQUEL_SNACK_DIST);
			world->dis.selection = LEQUEL_SNACK_DIST;
			break;
		case LEQUEL_BONBON_DIST:
			update_sprite_achat(&world->dis, LEQUEL_BONBON_DIST);
			world->dis.selection = LEQUEL_BONBON_DIST;
			break;
		case LEQUEL_PILE_DIST:
			update_sprite_achat(&world->dis, LEQUEL_PILE_DIST);
			world->dis.selection = LEQUEL_PILE_DIST;
			break;
		case LEQUEL_ACHAT_DIST:
			verif_achat(world,ecran);
			break;
		case LEQUEL_RETOUR_DIST:
			world->dis.ouvert = false;
			break;
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void verif_click_bouton_dis(bouton_dist_t* b, souris_t* s, world_t *world, SDL_Surface *ecran){
	if((s->click_x >= b->x) && (s->click_x <= b->x + b->largeur)){
		if((s->click_y >= b->y) && (s->click_y <= b->y + b->hauteur)){
			lire_bouton(b,world,ecran);
			s->click_x = -100;
			s->click_y = -100;
			return;
		}
	}
}

void verif_click_dis(distributeur_t* d, world_t *world, SDL_Surface *ecran){
	for(int i = 0; i<d->nbbouton; i++){
		verif_click_bouton_dis(&d->tabbouton[i],&d->souris, world, ecran);
	}
}

/////////////////////////////////

void verif_pos_bouton_dis(bouton_dist_t* b, souris_t* s){
	if((s->x >= b->x) && (s->x <= b->x + b->largeur)){
		if((s->y >= b->y) && (s->y <= b->y + b->hauteur)){
			b->sprite = b->b2;
			return;
		}
	}
	b->sprite = b->b1;
}

void verif_pos_dis(distributeur_t* d){
	for(int i = 0; i<d->nbbouton; i++){
		verif_pos_bouton_dis(&d->tabbouton[i],&d->souris);
	}
}

/////////////////////////////////

void verif_dis(distributeur_t* d, world_t *world, SDL_Surface *ecran){
	verif_pos_dis(d);
	verif_click_dis(d,world,ecran);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void update_click_souris_dis(souris_t* s, int x, int y){
	s->click_x = x;
	s->click_y = y;
}

void update_pos_souris_dis(souris_t* s, int x, int y){
	s->x = x;
	s->y = y;	
}

/////////////////////////////////

void handle_event_dis(SDL_Event *event, world_t* world){
	int mouseX, mouseY;
	Uint8 *keystates;
	while( SDL_PollEvent( event ) ) {
		//Si l'utilisateur a cliqué sur le X de la fenêtre
		if( event->type == SDL_QUIT ) {
			//On quitte le programme
			world->gameover = 1;
			world->dis.ouvert = false;
		}
		/* Si l'utilisateur appuie sur
		la touche droite de la souris */
		if( event->type == SDL_MOUSEBUTTONDOWN){
              		SDL_GetMouseState(&mouseX, &mouseY);
			update_click_souris_dis(&world->dis.souris, mouseX, mouseY);
		}
		if( event->type == SDL_MOUSEMOTION){
			//printf("BOUGE\n");
			SDL_GetMouseState(&mouseX, &mouseY);
			update_pos_souris_dis(&world->dis.souris, mouseX, mouseY);
		}
		keystates = SDL_GetKeyState( NULL );
		if( keystates[ SDLK_p ] ) {
			world->dis.ouvert = false;
		}
	}
} 

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void init_graphics_rouleau_distributeur(SDL_Surface *ecran,rouleau_t* r){
	set_transparence(ecran, r->item_1, 255, 0, 255);
	set_transparence(ecran, r->item_2, 255, 0, 255);
	set_transparence(ecran, r->item_3, 255, 0, 255);
	set_transparence(ecran, r->anneau, 255, 0, 255);
}

void init_graphics_bouton_distributeur(SDL_Surface *ecran,bouton_dist_t* b){
	set_transparence(ecran, b->b1, 255, 0, 255);
	set_transparence(ecran, b->b2, 255, 0, 255);
}

void  init_graphics_distributeur(SDL_Surface *ecran, distributeur_t* d ){
	set_transparence(ecran, d->devant, 255, 0, 255);
	for(int i = 0; i<d->nbrouleau; i++){
		init_graphics_rouleau_distributeur(ecran,&d->tabrouleau[i]);
	}
	for(int i = 0; i<d->nbbouton; i++){
		init_graphics_bouton_distributeur(ecran,&d->tabbouton[i]);
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void boucle_distributeur(world_t *world,SDL_Surface *ecran){
	SDL_Event event_dis;
	init_data_distributeur(&world->dis);
	init_graphics_distributeur(ecran,&world->dis);	
	while(world->dis.ouvert == true){
		handle_event_dis(&event_dis, world);
		verif_dis(&world->dis,world,ecran);
		refresh_graphics_dis(ecran,&world->dis);
	}
	return;
}
