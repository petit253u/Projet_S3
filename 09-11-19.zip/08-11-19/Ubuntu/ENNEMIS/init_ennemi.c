#include "../GENERAL/general.h"

void init_graphics_ennemi(ennemi_t* e,SDL_Surface *ecran){
	set_transparence(ecran, e->sprite, 255, 0, 255);
}

void init_data_ennemi(ennemi_t* e){
	int ennemi = (rand() % 6) + 1;
	switch(ennemi){
		case 1 :
			init_data_ennemi_ratafeuille(e);
			break;
		case 2 :
			init_data_ennemi_ratabulbe(e);
			break;
		case 3 :
			init_data_ennemi_rataracine(e);
			break;
		case 4 :
			init_data_ennemi_ratafleur(e);
			break;
		case 5 :
			init_data_ennemi_foregeon(e);
			break;
		case 6 :
			init_data_ennemi_corbachef(e);
			break;
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////

void init_graphics_ennemi_boss(ennemi_boss_t* e,SDL_Surface *ecran){
	set_transparence(ecran, e->sprite, 255, 0, 255);
}

void init_data_ennemi_boss(ennemi_boss_t* e, int ennemi){
	switch(ennemi){
		case 1 :
			init_data_ennemi_fleur(e);
			break;
	}
}
