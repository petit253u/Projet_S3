#include "../GENERAL/general.h"

///////////////////////////////////////////////////////////////////////////////////////////////////////////

void refresh_graphics_bouton_amelio(SDL_Surface *ecran,bouton_amelio_t* b){
	apply_surface(b->sprite,ecran, b->x,b->y);
}

void refresh_graphics_amelio(SDL_Surface *ecran, amelioration_t* a){
	apply_surface(a->fond,ecran, 0,0);;
	for(int i = 0; i<a->nbamelio; i++){
		refresh_graphics_bouton_amelio(ecran,&a->tabamelio[i]);
	}
	refresh_surface(ecran);
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void lire_bouton_amelio(bouton_amelio_t* b, world_t *world, SDL_Surface *ecran){
	switch(b->lequel){
		case LEQUEL_PV_AMELIO:
			
			break;
		case LEQUEL_DEFENSE_AMELIO:

			break;
		case LEQUEL_ATTAQUE_AMELIO:

			break;
	}
	world->amelio.ouvert = false;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void verif_click_bouton_amelio(bouton_amelio_t* b, souris_t* s, world_t *world, SDL_Surface *ecran){
	if((s->click_x >= b->x) && (s->click_x <= b->x + b->largeur)){
		if((s->click_y >= b->y) && (s->click_y <= b->y + b->hauteur)){
			lire_bouton_amelio(b,world,ecran);
			s->click_x = -100;
			s->click_y = -100;
			return;
		}
	}
}

void verif_click_amelio(amelioration_t* a, world_t *world, SDL_Surface *ecran){
	for(int i = 0; i<a->nbamelio; i++){
		verif_click_bouton_amelio(&a->tabamelio[i],&a->souris, world, ecran);
	}
}

/////////////////////////////////

void verif_pos_bouton_amelio(bouton_amelio_t* b, souris_t* s){
	if((s->x >= b->x) && (s->x <= b->x + b->largeur)){
		if((s->y >= b->y) && (s->y <= b->y + b->hauteur)){
			b->sprite = b->b2;
			return;
		}
	}
	b->sprite = b->b1;
}

void verif_pos_amelio(amelioration_t* a){
	for(int i = 0; i<a->nbamelio; i++){
		verif_pos_bouton_amelio(&a->tabamelio[i],&a->souris);
	}
}

/////////////////////////////////

void verif_amelio(amelioration_t* a, world_t *world, SDL_Surface *ecran){
	verif_pos_amelio(a);
	verif_click_amelio(a,world,ecran);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void update_click_souris_amelio(souris_t* s, int x, int y){
	s->click_x = x;
	s->click_y = y;
}

void update_pos_souris_amelio(souris_t* s, int x, int y){
	s->x = x;
	s->y = y;	
}

/////////////////////////////////

void handle_event_amelio(SDL_Event *event, world_t* world){
	int mouseX, mouseY;
	Uint8 *keystates;
	while( SDL_PollEvent( event ) ) {
		//Si l'utilisateur a cliqué sur le X de la fenêtre
		if( event->type == SDL_QUIT ) {
			//On quitte le programme
			world->gameover = 1;
			world->amelio.ouvert = false;
		}
		/* Si l'utilisateur appuie sur
		la touche droite de la souris */
		if( event->type == SDL_MOUSEBUTTONDOWN){
              		SDL_GetMouseState(&mouseX, &mouseY);
			update_click_souris_amelio(&world->amelio.souris, mouseX, mouseY);
		}
		if( event->type == SDL_MOUSEMOTION){
			//printf("BOUGE\n");
			SDL_GetMouseState(&mouseX, &mouseY);
			update_pos_souris_amelio(&world->amelio.souris, mouseX, mouseY);
		}
		keystates = SDL_GetKeyState( NULL );
		if( keystates[ SDLK_p ] ) {
			world->amelio.ouvert = false;
		}
	}
} 

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void init_graphics_bouton_amelio(SDL_Surface *ecran,bouton_amelio_t* b){
	set_transparence(ecran, b->b1, 255, 0, 255);
	set_transparence(ecran, b->b2, 255, 0, 255);
}

void  init_graphics_amelio(SDL_Surface *ecran, amelioration_t* a ){
	for(int i = 0; i<a->nbamelio; i++){
		init_graphics_bouton_amelio(ecran,&a->tabamelio[i]);
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void boucle_amelio(world_t *world,SDL_Surface *ecran){
	SDL_Event event_amelio;
	init_amelio(&world->amelio);
	init_graphics_amelio(ecran,&world->amelio);	
	while(world->amelio.ouvert == true){
		handle_event_amelio(&event_amelio, world);
		verif_amelio(&world->amelio,world,ecran);
		refresh_graphics_amelio(ecran,&world->amelio);
	}
	return;
}
