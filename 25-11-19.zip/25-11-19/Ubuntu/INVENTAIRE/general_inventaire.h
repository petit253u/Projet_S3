/**
* \file general_fuir.h
* \brief Module de structure et constante
* \author 
* \version 0.1
* \date 
*/

#include "../GENERAL/sdl-light.h"
#include <stdbool.h> 

///////////////////////////////////////////////////////

#define NB_CODE_MAX 200

/////////////////////

#define NB_ITEM_DIF 5

/////////////////////

#define CODE_FIOLE_INV 101

#define CODE_SNACK_INV 102

#define CODE_BONBON_INV 103

#define CODE_PILE_INV 104

#define CODE_FROMAGE_INV 105

///////////////////////////////////////////////////////

#define NB_CLE_MAX 12

/////////////////////

#define NB_CLE_DIF 12

/////////////////////

#define CODE_CLE_BELIER_INV 201

#define CODE_CLE_TAUREAU_INV 202

#define CODE_CLE_GEMEAU_INV 203

#define CODE_CLE_CANCER_INV 204

#define CODE_CLE_LION_INV 205

#define CODE_CLE_VIERGE_INV 206

#define CODE_CLE_BALNCE_INV 207

#define CODE_CLE_SCORPION_INV 208

#define CODE_CLE_SAGITAIRE_INV 209

#define CODE_CLE_CAPRICORNE_INV 210

#define CODE_CLE_VERSEAU_INV 211

#define CODE_CLE_POISSON_INV 212

///////////////////////////////////////////////////////

struct inventaire_s{
	int nbcode;
	int tabcode[NB_CODE_MAX];
	int nbcle;
	int tabcle[NB_CLE_MAX];
};
typedef struct inventaire_s inventaire_t;
