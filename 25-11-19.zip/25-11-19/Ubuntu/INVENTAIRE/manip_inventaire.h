/**
* \file init_fuir.h
* \brief Module d'inititialisation
* \author 
* \version 0.1
* \date 
*/

#ifndef MANIP_INVENTAIRE_H
#define MANIP_INVENTAIRE_H

#include "../GENERAL/sdl-light.h"

void recalage_tab_inventaire_item(inventaire_t* inv, int i);

////////////////////

void retirer_element_inventaire_item(inventaire_t* inv, int CODE);

///////////////////////////////////////////////////////

bool est_la_element_inventaire_item(inventaire_t* inv, int CODE);

///////////////////////////////////////////////////////

void ajout_element_inventaire_item(inventaire_t* inv, int CODE);

#endif
