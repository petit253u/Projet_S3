/**
 * \file sdl-light.c
 * \brief sur-couche de SDL pour simplifier son utilisation pour le projet
 * \author Mathieu Constant
 * \version 0.1
 * \date 13 mars 2019
 */

#include "sdl-light.h"
#include <SDL_mixer.h>

void init_audio(){
	if(Mix_OpenAudio(44100 , MIX_DEFAULT_FORMAT , 2 , 4096) == 1)
	{
		printf("Erreur Mix_OpenAudio fonction init_sound\n");
	}
}
