/**
* \file general_joueur.h
* \brief Module de structure et constante
* \author 
* \version 0.1
* \date 
*/

#include "../GENERAL/sdl-light.h"
#include <stdbool.h> 

///////////////////////////////////////////////////////

#define NB_PATERNE_CUBE_MAX 4

#define NB_PATERNE_FLL_MAX 4

#define NB_CHAR_MAX 20

///////////////////////////////////////////////////////


struct ennemi_s{
	int pv;
	int fuir_dif;
	paterne_cube_t paterne[NB_PATERNE_CUBE_MAX];
	int x;
	int y;
	SDL_Surface* sprite;
	char nom[NB_CHAR_MAX];
};
typedef struct ennemi_s ennemi_t;

struct ennemi_boss_s{
	int pv;
	int fuir_dif;
	paterne_fll_t paterne[NB_PATERNE_FLL_MAX];
	int x; 
	int y;
	SDL_Surface* sprite;
	SDL_Surface* s1;
	SDL_Surface* s2;
};
typedef struct ennemi_boss_s ennemi_boss_t;
