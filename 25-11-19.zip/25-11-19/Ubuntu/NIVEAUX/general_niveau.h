/**
* \file general_fuir.h
* \brief Module de structure et constante
* \author 
* \version 0.1
* \date 
*/

#include "../GENERAL/sdl-light.h"
#include <stdbool.h> 

///////////////////////////////////////////////////////

#define NB_SALLE_MAX 10
#define NB_OBJET_PAR_SALLE_MAX 50

//////////////////////

#define CODE_NIVEAU_1 1
#define CODE_NIVEAU_2 2
#define CODE_NIVEAU_3 3

///////////////////////////////////////////////////////

struct salle_s{
	int nb_objet;
	objet_t tabobjet[NB_OBJET_PAR_SALLE_MAX];
	SDL_Surface* fond;
	char nom;
};
typedef struct salle_s salle_t;

struct niveau_s{
	int nb_salle;
	int tabsalle[NB_SALLE_MAX];
	bool lire_time; // true : verifie le temps, false : non  
	temps_t temps;
};
typedef struct niveau_s niveau_t;

