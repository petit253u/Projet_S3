#include "../../GENERAL/general.h"

void init_salle_i_niv_1(int i, salle_t* salle){
	switch(i){
		case 1:
			init_salle_1_niv_1(salle);
			break;
		case 2:
			init_salle_2_niv_1(salle);
			break;
		case 3:
			init_salle_3_niv_1(salle);
			break;
		case 4:
			init_salle_4_niv_1(salle);
			break;
		case 5:
			init_salle_5_niv_1(salle);
			break;
		case 6:
			init_salle_6_niv_1(salle);
			break;
		case 7:
			init_salle_7_niv_1(salle);
			break;
		case 8:
			init_salle_8_niv_1(salle);
			break;
	}
}

void init_niveau_1(niveau_t* n){
	n->nb_salle = NB_SALLE_NIV_1;
	n->lire_time = true;
	init_temps_niveau(&n->temps);
	for(int i=0; i<NB_SALLE_NIV_1; i++){
		init_salle_i_niv_1(i+1, &n->tabsalle[i])
	}
}
