/**
* \file init_fuir.h
* \brief Module d'inititialisation
* \author 
* \version 0.1
* \date 
*/

#ifndef INIT_NIVEAU_1_H
#define INIT_NIVEAU_1_H

#include "../../GENERAL/sdl-light.h"

void init_salle_i_niv_1(int i, salle_t* salle);

void init_niveau_1(niveau_t* n);

#endif
