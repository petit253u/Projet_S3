#ifndef INIT_PIERRE_AMELIO_H
#define INIT_PIERRE_AMELIO_H

#include "../../../GENERAL/sdl-light.h"

void init_data_pierre_amelio(pierre_amelio_t* p, int x, int y);

#endif
