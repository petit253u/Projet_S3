#ifndef INIT_PORTE_H
#define INIT_PORTE_H

#include "../../../GENERAL/sdl-light.h"

void init_lire_code_porte(porte_t* p);

void init_data_porte(porte_t* p, int x, int y);

#endif
