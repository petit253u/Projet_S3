#ifndef INIT_BONBON_H
#define INIT_BONBON_H

#include "../../../GENERAL/sdl-light.h"

void init_data_bonbon(bonbon_t* b, int x, int y);

#endif
