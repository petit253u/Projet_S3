#ifndef INIT_SNACK_H
#define INIT_SNACK_H

#include "../../../GENERAL/sdl-light.h"

void init_data_snack(snack_t* s, int x, int y);

#endif
