#include "../../../GENERAL/general.h"

void init_data_snack(snack_t* s, int x, int y){
	s->x = x;
	s->y = y;
	s->largeur = LARGEUR_SNACK;
	s->hauteur = HAUTEUR_SNACK;
	s->s1 = ;
	s->s2 = ;
	s->sprite = s->s1;
}
