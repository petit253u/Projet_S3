#ifndef INIT_FIOLE_H
#define INIT_FIOLE_H

#include "../../../GENERAL/sdl-light.h"

void init_data_fiole(fiole_t* f, int x, int y);

#endif
