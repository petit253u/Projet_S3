#include "../../../GENERAL/general.h"

void init_data_fiole(fiole_t* f, int x, int y){
	f->x = x;
	f->y = y;
	f->largeur = LARGEUR_FIOLE;
	f->hauteur = HAUTEUR_FIOLE;
	f->s1 = ;
	f->s2 = ;
	f->sprite = f->s1;
}
