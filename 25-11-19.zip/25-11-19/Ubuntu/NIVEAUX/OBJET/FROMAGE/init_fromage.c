#include "../../../GENERAL/general.h"

void init_data_fromage(fromage_t* f, int x, int y){
	f->x = x;
	f->y = y;
	f->largeur = LARGEUR_FROMAGE;
	f->hauteur = HAUTEUR_FROMAGE;
	f->s1 = ;
	f->s2 = ;
	f->sprite = f->s1;
}
