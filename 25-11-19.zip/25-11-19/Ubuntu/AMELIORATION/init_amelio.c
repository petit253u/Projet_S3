#include "../GENERAL/general.h"

void init_souris_amelio(souris_t* s){
	s->x = -100;
	s->y = -100;
	s->click_x = -100;
	s->click_y = -100;
}

////////////////////////////////////////////////////////////////////////////////////////////

void init_bouton_amelio_1(bouton_amelio_t* b){
	b->b1 = SDL_LoadBMP("RESSOURCES/AMELIO/amelio_pv.bmp");
	b->b2 = SDL_LoadBMP("RESSOURCES/AMELIO/amelio_pv_cliquable.bmp");
	b->sprite = b->b1;
	b->largeur = LARGEUR_BOUTON_AMELIO;
	b->hauteur = HAUTEUR_BOUTON_AMELIO;
	b->x = X_BOUTON_AMELIO_1;
	b->y = Y_BOUTON_AMELIO_1;
	b->lequel = LEQUEL_PV_AMELIO;
}

void init_bouton_amelio_2(bouton_amelio_t* b){
	b->b1 = SDL_LoadBMP("RESSOURCES/AMELIO/amelio_bouclier.bmp");
	b->b2 = SDL_LoadBMP("RESSOURCES/AMELIO/amelio_bouclier_cliquable.bmp");
	b->sprite = b->b1;
	b->largeur = LARGEUR_BOUTON_AMELIO;
	b->hauteur = HAUTEUR_BOUTON_AMELIO;
	b->x = X_BOUTON_AMELIO_2;
	b->y = Y_BOUTON_AMELIO_2;
	b->lequel = LEQUEL_DEFENSE_AMELIO;
}

void init_bouton_amelio_3(bouton_amelio_t* b){
	b->b1 = SDL_LoadBMP("RESSOURCES/AMELIO/amelio_epee.bmp");
	b->b2 = SDL_LoadBMP("RESSOURCES/AMELIO/amelio_epee_cliquable.bmp");
	b->sprite = b->b1;
	b->largeur = LARGEUR_BOUTON_AMELIO;
	b->hauteur = HAUTEUR_BOUTON_AMELIO;
	b->x = X_BOUTON_AMELIO_3;
	b->y = Y_BOUTON_AMELIO_3;
	b->lequel = LEQUEL_ATTAQUE_AMELIO;
}

void init_bouton_amelio_i(bouton_amelio_t* b,int i){
	switch(i){
		case LEQUEL_PV_AMELIO:
			init_bouton_amelio_1(b);
			break;
		case LEQUEL_DEFENSE_AMELIO:
			init_bouton_amelio_2(b);
			break;
		case LEQUEL_ATTAQUE_AMELIO:
			init_bouton_amelio_3(b);
			break;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////

void init_amelio(amelioration_t* a){
	a->ouvert = true;
	a->fond = SDL_LoadBMP("RESSOURCES/AMELIO/plateau_amelio.bmp");
	a->nbamelio = 3;
	for(int i=0; i<a->nbamelio; i++){
		init_bouton_amelio_i(&a->tabamelio[i], i+1);
	}
	init_souris_amelio(&a->souris);
}

